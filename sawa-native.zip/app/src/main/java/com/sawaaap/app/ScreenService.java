package com.sawaaap.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * C141: مشاركة الشاشة في غرف سوا من تطبيق أندرويد.
 * WebView لا يدعم getDisplayMedia ⇒ نلتقط الشاشة أصليّاً (MediaProjection → ImageReader) ونرسل إطاراتٍ JPEG
 * (حتّى ٨ في الثانية، أطول ضلعٍ ١٢٨٠) إلى الواجهة، فتصنع منها مسار فيديو (MediaStreamTrackGenerator أو canvas)
 * يُرسَل في الغرفة كمشاركة الشاشة في المتصفّح تماماً. خدمةٌ أماميّة من نوع mediaProjection (شرط أندرويد ١٠+) وإشعارٌ بزرّ «إيقاف».
 */
public class ScreenService extends Service {
    static final int ID = 7101;
    static final String ACT_STOP = "com.sawaaap.app.SCREEN_STOP";
    static volatile ScreenService inst;

    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader ir;
    private HandlerThread ht;
    private Handler bg;
    private DisplayManager.DisplayListener dl;
    private int curW, curH;
    private long lastAt;
    private volatile String lastB64;
    private volatile int lastW, lastH;
    private boolean ended;
    private final Handler main = new Handler(Looper.getMainLooper());

    public static void start(Context ctx, int code, Intent data) {
        Intent i = new Intent(ctx, ScreenService.class);
        i.putExtra("code", code);
        i.putExtra("data", data);
        try { ContextCompat.startForegroundService(ctx, i); } catch (Exception e) { MainActivity.screenEvent("error"); }
    }

    public static void stop(Context ctx) {
        try { ctx.stopService(new Intent(ctx, ScreenService.class)); } catch (Exception e) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACT_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (inst != null && mp != null) return START_NOT_STICKY;   // تعمل أصلاً
        try {
            int type = Build.VERSION.SDK_INT >= 29 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION : 0;
            ServiceCompat.startForeground(this, ID, note(), type);
        } catch (Exception e) {
            MainActivity.screenEvent("error"); stopSelf(); return START_NOT_STICKY;
        }
        try {
            int code = intent == null ? 0 : intent.getIntExtra("code", 0);
            Intent data = intent == null ? null : (Build.VERSION.SDK_INT >= 33 ? intent.getParcelableExtra("data", Intent.class) : intent.getParcelableExtra("data"));
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mp = (mpm == null || data == null) ? null : mpm.getMediaProjection(code, data);
            if (mp == null) { MainActivity.screenEvent("error"); stopSelf(); return START_NOT_STICKY; }
            inst = this;
            ht = new HandlerThread("sawa-screen"); ht.start();
            bg = new Handler(ht.getLooper());
            // أندرويد ١٤+: يجب تسجيل المستمع قبل إنشاء الشاشة الافتراضيّة
            mp.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(ScreenService.this::stopSelf); }
            }, bg);
            setup();
            watchRotation();
            keepAlive();
            MainActivity.screenEvent("started");
        } catch (Exception e) {
            MainActivity.screenEvent("error"); stopSelf();
        }
        return START_NOT_STICKY;
    }

    private Notification note() {
        Notifier.channels(this);
        boolean en = Notifier.en(this, null);
        Intent si = new Intent(this, ScreenService.class).setAction(ACT_STOP);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stop = PendingIntent.getService(this, ID, si, fl);
        PendingIntent back = Notifier.openUrl(this, "https://www.sawaaap.com/", ID + 1);
        return new NotificationCompat.Builder(this, Notifier.CH_ONGOING)
                .setSmallIcon(R.drawable.ic_stat_sawa)
                .setContentTitle(Notifier.tr(en, "تعرض شاشتك في سوا", "Sharing your screen on Sawa"))
                .setContentText(Notifier.tr(en, "يرى من في الغرفة ما على شاشتك — اضغط «إيقاف» لإنهاء العرض", "People in the room can see your screen — tap Stop to end"))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(back)
                .addAction(0, Notifier.tr(en, "إيقاف", "Stop"), stop)
                .addAction(0, Notifier.tr(en, "العودة إلى سوا", "Back to Sawa"), back)
                .build();
    }

    private DisplayMetrics metrics() {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        if (wm != null) wm.getDefaultDisplay().getRealMetrics(dm);
        else dm = getResources().getDisplayMetrics();
        return dm;
    }

    /** الشاشة الافتراضيّة بحجم الشاشة الحقيقيّة مصغّراً (أطول ضلع ١٢٨٠) — وتُعاد عند تدوير الهاتف */
    private void setup() {
        DisplayMetrics dm = metrics();
        int w = dm.widthPixels, h = dm.heightPixels;
        float k = Math.min(1f, 1280f / Math.max(w, h));
        int W = Math.max(2, Math.round(w * k) & ~1), H = Math.max(2, Math.round(h * k) & ~1);
        if (W == curW && H == curH && vd != null) return;
        curW = W; curH = H;
        ImageReader old = ir;
        ir = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2);
        ir.setOnImageAvailableListener(this::onImage, bg);
        if (vd == null) {
            vd = mp.createVirtualDisplay("sawa-screen", W, H, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.getSurface(), null, bg);
        } else {
            vd.resize(W, H, dm.densityDpi);
            vd.setSurface(ir.getSurface());
        }
        if (old != null) { try { old.close(); } catch (Exception e) { } }
    }

    private void watchRotation() {
        DisplayManager dmg = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        if (dmg == null) return;
        dl = new DisplayManager.DisplayListener() {
            @Override public void onDisplayAdded(int id) { }
            @Override public void onDisplayRemoved(int id) { }
            @Override public void onDisplayChanged(int id) {
                if (id != Display.DEFAULT_DISPLAY || ended || mp == null) return;
                try { setup(); } catch (Exception e) { }
            }
        };
        dmg.registerDisplayListener(dl, bg);
    }

    /** شاشةٌ ساكنة لا تنتج إطارات ⇒ نعيد آخر إطار كلّ ثانيتين حتّى يراه من انضمّ للتوّ */
    private void keepAlive() {
        bg.postDelayed(new Runnable() {
            @Override public void run() {
                if (ended) return;
                String b = lastB64;
                if (b != null && SystemClock.uptimeMillis() - lastAt > 1800) { lastAt = SystemClock.uptimeMillis(); MainActivity.screenFrame(b, lastW, lastH); }
                bg.postDelayed(this, 2000);
            }
        }, 2000);
    }

    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null || ended) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastAt < 120 || MainActivity.scrBusy()) return;   // ≤ ٨ إطارات/ث، ولا نكدّس إن تأخّرت الواجهة
            lastAt = now;
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int ps = p.getPixelStride(), rs = p.getRowStride(), iw = img.getWidth(), ih = img.getHeight();
            int padW = rs / ps;
            Bitmap bmp = Bitmap.createBitmap(padW, ih, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            Bitmap out = padW != iw ? Bitmap.createBitmap(bmp, 0, 0, iw, ih) : bmp;
            ByteArrayOutputStream os = new ByteArrayOutputStream(96 * 1024);
            out.compress(Bitmap.CompressFormat.JPEG, 62, os);
            if (out != bmp) out.recycle();
            bmp.recycle();
            String b64 = Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP);
            lastB64 = b64; lastW = iw; lastH = ih;
            MainActivity.screenFrame(b64, iw, ih);
        } catch (Exception e) {
            // إطارٌ تالف — نتجاوزه
        } finally {
            if (img != null) { try { img.close(); } catch (Exception e) { } }
        }
    }

    @Override
    public void onDestroy() {
        ended = true;
        inst = null;
        try { if (dl != null) ((DisplayManager) getSystemService(Context.DISPLAY_SERVICE)).unregisterDisplayListener(dl); } catch (Exception e) { }
        try { if (vd != null) vd.release(); } catch (Exception e) { }
        try { if (ir != null) ir.close(); } catch (Exception e) { }
        try { if (mp != null) mp.stop(); } catch (Exception e) { }
        vd = null; ir = null; mp = null; lastB64 = null;
        if (ht != null) { try { ht.quitSafely(); } catch (Exception e) { } }
        try { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE); } catch (Exception e) { }
        MainActivity.screenEvent("stopped");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
