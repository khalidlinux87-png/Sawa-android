package com.sawaaap.app;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * C88: جهات اتّصال الهاتف — تُقرأ على الجهاز فقط لإرسال رسالةٍ نصّيّة فيها رمز سوا.
 * لا تُرفع إلى الخادم ولا تُحفظ: تُعاد إلى الواجهة مرّةً واحدة عند فتح القائمة.
 */
final class PhoneContacts {
    private PhoneContacts() {}

    static JSONArray read(Context ctx, int max) {
        JSONArray out = new JSONArray();
        Set<String> seen = new HashSet<>();
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (c == null) return out;
            while (c.moveToNext() && out.length() < max) {
                String name = c.getString(0), num = c.getString(1);
                if (num == null) continue;
                String key = num.replaceAll("[^0-9]", "");
                if (key.length() < 6) continue;
                if (key.length() > 9) key = key.substring(key.length() - 9);   // نفس الرقم بصيغتين (محلّيّ/دوليّ) = واحد
                if (!seen.add(key)) continue;
                JSONObject o = new JSONObject();
                o.put("n", name == null ? "" : name);
                o.put("p", num.trim());
                out.put(o);
            }
        } catch (Exception e) {
            // بلا إذن أو مزوّد جهاتٍ معطّل ⇒ قائمة فارغة
        } finally {
            if (c != null) try { c.close(); } catch (Exception e) { }
        }
        return out;
    }
}
