package com.sawaaap.app;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * C89: الملفّات في التطبيق الأصليّ.
 * ١) اختيار الملفّات: كان p.createIntent() يأخذ أوّل نوعٍ فقط («صورة أو فيديو» لا يُظهر الفيديو) ولا يعيد إلّا ملفّاً واحداً،
 *    ولا كاميرا. الآن: كلّ الأنواع المطلوبة · اختيار متعدّد · التقاط صورة/فيديو بالكاميرا.
 * ٢) فتح/حفظ/مشاركة ملفٍّ وصل في المحادثة: WebView لا يُنزّل روابط blob: (كان «فتح الملفّ» لا يفعل شيئاً).
 *    الواجهة ترسل الملفّ قطعاً (base64) ثمّ: فتح بتطبيقٍ مناسب · حفظ في «التنزيلات» · مشاركة.
 * ٣) «مشاركة إلى سوا» من أيّ تطبيق: نصوص وروابط وصور وفيديو وملفّات — تُنسخ إلى مجلّدٍ مؤقّت وتسحبها الواجهة قطعاً.
 */
final class FileBridge {
    private FileBridge() {}

    static String authority(Context c) { return c.getPackageName() + ".files"; }

    // ---------------- ١) اختيار الملفّات ----------------
    static Uri cameraOut = null;

    static Intent chooser(Context ctx, WebChromeClient.FileChooserParams p) {
        String[] acc = p.getAcceptTypes();
        List<String> mimes = new ArrayList<>();
        boolean wantImage = false, wantVideo = false;
        if (acc != null) for (String a0 : acc) {
            if (a0 == null) continue;
            for (String a : a0.split(",")) {
                a = a.trim().toLowerCase();
                if (a.isEmpty()) continue;
                if (a.startsWith(".")) {   // امتداد ⇒ نوعه
                    String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(a.substring(1));
                    if (m != null) a = m; else continue;
                }
                if (a.startsWith("image/")) wantImage = true;
                if (a.startsWith("video/")) wantVideo = true;
                if (!mimes.contains(a)) mimes.add(a);
            }
        }
        Intent get = new Intent(Intent.ACTION_GET_CONTENT);
        get.addCategory(Intent.CATEGORY_OPENABLE);
        get.setType(mimes.size() == 1 ? mimes.get(0) : "*/*");
        if (mimes.size() > 1) get.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
        if (p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) get.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

        List<Intent> extra = new ArrayList<>();
        cameraOut = null;
        try {
            // الكاميرا من القائمة فقط إن سُمح بها (تطبيقٌ يعلن إذن الكاميرا ولم يُمنح يُرفض له طلب الالتقاط)
            boolean camOk = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED;
            if ((wantImage || wantVideo) && camOk) {
                File dir = new File(ctx.getCacheDir(), "cam");
                dir.mkdirs();
                if (wantImage) {
                    File f = new File(dir, "IMG_" + System.currentTimeMillis() + ".jpg");
                    Uri u = FileProvider.getUriForFile(ctx, authority(ctx), f);
                    Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cam.putExtra(MediaStore.EXTRA_OUTPUT, u);
                    cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    cam.setClipData(ClipData.newRawUri("", u));
                    cameraOut = u;
                    extra.add(cam);
                }
                if (wantVideo) {
                    Intent vid = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                    vid.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 120);
                    extra.add(vid);
                }
            }
        } catch (Exception e) { cameraOut = null; }
        // C91: صورٌ/فيديو فقط ⇒ منتقي الصور في النظام (أندرويد ١٣+) — يدعم تحديد عدّة صور فعلاً،
        //      بينما معارض بعض الهواتف (Honor/Huawei) تتجاهل EXTRA_ALLOW_MULTIPLE فلا تسمح إلّا بصورة واحدة
        boolean onlyMedia = !mimes.isEmpty();
        for (String m : mimes) if (!(m.startsWith("image/") || m.startsWith("video/"))) onlyMedia = false;
        Intent main = get;
        boolean multi = p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        if (onlyMedia) {
            // C98: منتقي الصور الحديث (يدعم تحديد عدّة صور فعلاً) في كلّ إصدارٍ ممكن — كان لأندرويد ١٣+ وحده، فبقيت هواتف ١١/١٢
            //      ومعارض بعض الهواتف (Honor/Huawei…) التي تتجاهل EXTRA_ALLOW_MULTIPLE على صورةٍ واحدة:
            //      ١) أندرويد ١٣+ أو ١١/١٢ بتحديث النظام (SdkExtensions R ≥ 2) ⇒ ACTION_PICK_IMAGES
            //      ٢) منتقي خدمات Google Play (نسخةٌ للإصدارات الأقدم) ⇒ ACTION_SYSTEM_FALLBACK_PICK_IMAGES
            //      ٣) وإلّا: مدير الملفّات (ACTION_OPEN_DOCUMENT) — يدعم التحديد المتعدّد بالضغط المطوّل
            Intent pick = null;
            if (sysPicker()) { pick = new Intent("android.provider.action.PICK_IMAGES"); if (multi) pick.putExtra("android.provider.extra.PICK_IMAGES_MAX", pickMax()); }
            else { pick = gmsPicker(ctx); if (pick != null && multi) pick.putExtra("com.google.android.gms.provider.extra.PICK_IMAGES_MAX", 20); }
            if (pick != null) {
                if (wantImage && !wantVideo) pick.setType("image/*");
                else if (wantVideo && !wantImage) pick.setType("video/*");
            } else if (multi) {
                pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(mimes.size() == 1 ? mimes.get(0) : "*/*");
                if (mimes.size() > 1) pick.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            if (pick != null) {
                main = pick;
                if (extra.isEmpty()) return pick;   // بلا كاميرا: المنتقي مباشرةً
            }
        } else if (multi) {
            // C98: ملفّات عامّة متعدّدة ⇒ مدير الملفّات (GET_CONTENT قد يفتح معرضاً يتجاهل التعدّد)
            Intent od = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            od.addCategory(Intent.CATEGORY_OPENABLE);
            od.setType(mimes.size() == 1 ? mimes.get(0) : "*/*");
            if (mimes.size() > 1) od.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
            od.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            main = od;
        }
        Intent ch = Intent.createChooser(main, wantImage || wantVideo ? "اختر صورة أو فيديو" : "اختر ملفّاً");
        if (!extra.isEmpty()) ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, extra.toArray(new Intent[0]));
        return ch;
    }

    static boolean sysPicker() {
        if (Build.VERSION.SDK_INT >= 33) return true;
        if (Build.VERSION.SDK_INT >= 30) { try { return android.os.ext.SdkExtensions.getExtensionVersion(Build.VERSION_CODES.R) >= 2; } catch (Throwable t) { } }
        return false;
    }
    static int pickMax() { int mx = 20; try { if (Build.VERSION.SDK_INT >= 33) mx = Math.min(20, MediaStore.getPickImagesMaxLimit()); } catch (Throwable t) { } return Math.max(2, mx); }
    static Intent gmsPicker(Context ctx) {
        try {
            Intent i = new Intent("androidx.activity.result.contract.action.PICK_IMAGES");
            android.content.pm.ResolveInfo r = ctx.getPackageManager().resolveActivity(i, android.content.pm.PackageManager.MATCH_SYSTEM_ONLY);
            if (r == null || r.activityInfo == null) return null;
            i.setClassName(r.activityInfo.packageName, r.activityInfo.name);
            return i;
        } catch (Throwable t) { return null; }
    }

    static Uri[] result(Context ctx, int resultCode, Intent data) {
        if (resultCode != android.app.Activity.RESULT_OK) { cameraOut = null; return null; }
        List<Uri> out = new ArrayList<>();
        if (data != null) {
            ClipData cd = data.getClipData();
            if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) { Uri u = cd.getItemAt(i).getUri(); if (u != null && !u.equals(cameraOut)) out.add(u); }
            if (data.getData() != null && !out.contains(data.getData())) out.add(data.getData());
        }
        if (out.isEmpty() && cameraOut != null) out.add(cameraOut);   // صورةٌ من الكاميرا (لا تعود في data)
        cameraOut = null;
        return out.isEmpty() ? null : out.toArray(new Uri[0]);
    }

    // ---------------- ٢) ملفٌّ من المحادثة إلى الهاتف ----------------
    private static final Map<String, Object[]> OUT = new HashMap<>();   // id -> {File, name, mime, OutputStream}

    static String begin(Context ctx, String name, String mime) {
        try {
            File dir = new File(ctx.getCacheDir(), "out");
            dir.mkdirs();
            String id = Long.toString(System.nanoTime(), 36);
            String safe = safeName(name, mime);
            File sub = new File(dir, id); sub.mkdirs();
            File f = new File(sub, safe);
            OUT.put(id, new Object[]{f, safe, mime == null || mime.isEmpty() ? guessMime(safe) : mime, new FileOutputStream(f)});
            return id;
        } catch (Exception e) { return ""; }
    }

    static boolean chunk(String id, String b64) {
        Object[] o = OUT.get(id);
        if (o == null) return false;
        try { ((OutputStream) o[3]).write(Base64.decode(b64, Base64.DEFAULT)); return true; }
        catch (Exception e) { return false; }
    }

    /** action: open | save | share — يعيد JSON {ok, where?, error?} */
    static String end(MainActivity act, String id, String action) {
        Object[] o = OUT.remove(id);
        JSONObject r = new JSONObject();
        try {
            if (o == null) { r.put("ok", false); r.put("error", "gone"); return r.toString(); }
            ((OutputStream) o[3]).close();
            File f = (File) o[0]; String name = (String) o[1], mime = (String) o[2];
            if ("save".equals(action)) {
                String where = saveToDownloads(act, f, name, mime);
                r.put("ok", where != null); if (where != null) r.put("where", where);
                return r.toString();
            }
            Uri u = FileProvider.getUriForFile(act, authority(act), f);
            Intent i;
            if ("share".equals(action)) {
                i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.setClipData(ClipData.newRawUri("", u));
                i = Intent.createChooser(i, "مشاركة");
            } else {
                i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(u, mime);
                i = Intent.createChooser(i, "فتح بواسطة");
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            r.put("ok", true);
        } catch (Exception e) {
            try { r.put("ok", false); r.put("error", String.valueOf(e.getMessage())); } catch (Exception e2) { }
        }
        return r.toString();
    }

    private static String saveToDownloads(Context ctx, File f, String name, String mime) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sawa");
                Uri dst = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (dst == null) return null;
                try (InputStream in = new FileInputStream(f); OutputStream out = ctx.getContentResolver().openOutputStream(dst)) { copy(in, out); }
                return "Download/Sawa/" + name;
            }
            File dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) return null;
            dir.mkdirs();
            File dst = new File(dir, name);
            try (InputStream in = new FileInputStream(f); OutputStream out = new FileOutputStream(dst)) { copy(in, out); }
            return dst.getAbsolutePath();
        } catch (Exception e) { return null; }
    }

    // ---------------- ٣) «مشاركة إلى سوا» من تطبيقٍ آخر ----------------
    private static final Map<String, File> IN = new HashMap<>();
    private static String pending = null;   // JSON ينتظر أن تأخذه الواجهة

    static boolean isShare(Intent i) {
        if (i == null) return false;
        String a = i.getAction();
        return Intent.ACTION_SEND.equals(a) || Intent.ACTION_SEND_MULTIPLE.equals(a);
    }

    /** يُنسخ ما شورِك إلى مجلّدٍ مؤقّت ويُحضَّر وصفُه للواجهة. */
    @SuppressWarnings("deprecation")
    static String importShare(Context ctx, Intent i) {
        try {
            JSONObject o = new JSONObject();
            CharSequence tx = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            String subj = i.getStringExtra(Intent.EXTRA_SUBJECT);
            String text = tx == null ? "" : tx.toString();
            if (subj != null && !subj.isEmpty() && !text.contains(subj)) text = text.isEmpty() ? subj : subj + "\n" + text;
            o.put("text", text);
            List<Uri> uris = new ArrayList<>();
            if (Intent.ACTION_SEND_MULTIPLE.equals(i.getAction())) {
                ArrayList<Uri> l = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (l != null) uris.addAll(l);
            } else {
                Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) uris.add(u);
            }
            if (uris.isEmpty() && i.getClipData() != null) {
                ClipData cd = i.getClipData();
                for (int k = 0; k < cd.getItemCount(); k++) if (cd.getItemAt(k).getUri() != null) uris.add(cd.getItemAt(k).getUri());
            }
            JSONArray files = new JSONArray();
            File dir = new File(ctx.getCacheDir(), "in");
            dir.mkdirs();
            int n = 0;
            for (Uri u : uris) {
                if (n >= 10) break;
                String name = displayName(ctx, u), mime = ctx.getContentResolver().getType(u);
                if (mime == null) mime = i.getType() != null && !i.getType().endsWith("*") ? i.getType() : guessMime(name);
                String id = Long.toString(System.nanoTime(), 36) + n;
                File f = new File(dir, id);
                long size;
                try (InputStream in = ctx.getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(f)) {
                    if (in == null) continue;
                    size = copyMax(in, out, 64L * 1024 * 1024);
                }
                if (size < 0) { f.delete(); JSONObject big = new JSONObject(); big.put("name", name); big.put("tooBig", true); files.put(big); continue; }
                IN.put(id, f);
                JSONObject fo = new JSONObject();
                fo.put("id", id); fo.put("name", name == null ? "file" : name); fo.put("mime", mime); fo.put("size", size);
                files.put(fo);
                n++;
            }
            o.put("files", files);
            if (text.isEmpty() && files.length() == 0) return null;
            pending = o.toString();
            return pending;
        } catch (Exception e) { return null; }
    }

    static String take() { String p = pending; pending = null; return p == null ? "" : p; }

    static String read(String id, int off, int len) {
        File f = IN.get(id);
        if (f == null) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            long skipped = 0; while (skipped < off) { long s = in.skip(off - skipped); if (s <= 0) break; skipped += s; }
            byte[] buf = new byte[Math.max(0, Math.min(len, 1024 * 1024))];
            int got = 0, r;
            while (got < buf.length && (r = in.read(buf, got, buf.length - got)) > 0) got += r;
            return Base64.encodeToString(buf, 0, got, Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }

    static void done(String id) { File f = IN.remove(id); if (f != null) f.delete(); }

    // ---------------- أدوات ----------------
    static String displayName(Context ctx, Uri u) {
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) { String n = c.getString(0); if (n != null && !n.isEmpty()) return n; }
        } catch (Exception e) { } finally { if (c != null) try { c.close(); } catch (Exception e) { } }
        String last = u.getLastPathSegment();
        return last == null ? "file" : last;
    }

    static String guessMime(String name) {
        String ext = name == null ? "" : MimeTypeMap.getFileExtensionFromUrl(name.replace(' ', '_'));
        String m = ext == null || ext.isEmpty() ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
        return m == null ? "application/octet-stream" : m;
    }

    static String safeName(String name, String mime) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\n\\r]", "_").trim();
        if (n.isEmpty()) n = "sawa-" + System.currentTimeMillis();
        if (!n.contains(".") && mime != null) {
            String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
            if (ext != null) n += "." + ext;
        }
        return n.length() > 120 ? n.substring(n.length() - 120) : n;
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] b = new byte[64 * 1024]; int r;
        while ((r = in.read(b)) > 0) out.write(b, 0, r);
    }

    /** ينسخ حتّى max بايت؛ يعيد -1 إن تجاوزه. */
    private static long copyMax(InputStream in, OutputStream out, long max) throws Exception {
        byte[] b = new byte[64 * 1024]; int r; long t = 0;
        while ((r = in.read(b)) > 0) { t += r; if (t > max) return -1; out.write(b, 0, r); }
        return t;
    }

    /** تنظيف الملفّات المؤقّتة القديمة (أكثر من يوم). */
    static void cleanup(Context ctx) {
        for (String d : new String[]{"out", "in", "cam"}) {
            File dir = new File(ctx.getCacheDir(), d);
            File[] l = dir.listFiles(); if (l == null) continue;
            long now = System.currentTimeMillis();
            for (File f : l) if (now - f.lastModified() > 86400000L) deleteRec(f);
        }
    }
    private static void deleteRec(File f) { File[] l = f.listFiles(); if (l != null) for (File x : l) deleteRec(x); f.delete(); }
}
