package com.sawaaap.app;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

/** خدمة أماميّة طوال المكالمة/الغرفة: أندرويد لا يوقف التطبيق في الخلفيّة، والميكروفون يبقى يعمل، والإشعار «مكالمة جارية» ظاهر. */
public class CallService extends Service {
    static volatile boolean running = false;

    public static void start(Context ctx, String title) {
        Intent i = new Intent(ctx, CallService.class);
        i.putExtra("title", title == null ? "" : title);
        try { ContextCompat.startForegroundService(ctx, i); } catch (Exception e) { /* بلا إذن ميكروفون بعد أو قيود الخلفيّة */ }
    }

    public static void stop(Context ctx) {
        try { ctx.stopService(new Intent(ctx, CallService.class)); } catch (Exception e) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent != null ? intent.getStringExtra("title") : "";
        Notification n = Notifier.ongoing(this, title);
        try {
            int type = Build.VERSION.SDK_INT >= 30 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0;
            ServiceCompat.startForeground(this, Notifier.ID_ONGOING, n, type);
            running = true;
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE); } catch (Exception e) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
