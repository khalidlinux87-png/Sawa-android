package com.sawaaap.app;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

/** خدمة أماميّة طوال المكالمة/الغرفة: أندرويد لا يوقف التطبيق في الخلفيّة، والميكروفون يبقى يعمل، والإشعار «مكالمة جارية» ظاهر. */
public class CallService extends Service {
    static volatile boolean running = false;
    // C291: مكالمة فيديو ⇒ الخدمة تحمل نوع «الكاميرا» أيضاً (أندرويد ١١+ يقطع الكاميرا عن تطبيقٍ في الخلفيّة بلا هذا النوع ⇒ صورةٌ سوداء عند الطرف الآخر)
    static volatile boolean video = false;
    static volatile String lastTitle = "";

    public static void start(Context ctx, String title) {
        Intent i = new Intent(ctx, CallService.class);
        lastTitle = title == null ? "" : title;
        i.putExtra("title", lastTitle);
        try { ContextCompat.startForegroundService(ctx, i); } catch (Exception e) { /* بلا إذن ميكروفون بعد أو قيود الخلفيّة */ }
    }

    /** C291: من الصفحة حين تصير المكالمة فيديو (أو تبدأ فيديو). */
    public static void setVideo(Context ctx, boolean on) {
        if (video == on) return;
        video = on;
        if (running) start(ctx, lastTitle);   // onStartCommand من جديد ⇒ startForeground بالنوع الجديد
    }

    public static void stop(Context ctx) {
        video = false;
        try { ctx.stopService(new Intent(ctx, CallService.class)); } catch (Exception e) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent != null ? intent.getStringExtra("title") : "";
        Notification n = Notifier.ongoing(this, title);
        try {
            int type = Build.VERSION.SDK_INT >= 30 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0;
            boolean cam = video && Build.VERSION.SDK_INT >= 30
                    && ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED;
            try {
                ServiceCompat.startForeground(this, Notifier.ID_ONGOING, n, cam ? type | ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA : type);
            } catch (Exception e) {
                // أندرويد ١٤+: نوع الكاميرا لا يبدأ والتطبيق في الخلفيّة (الردّ من القفل) ⇒ الميكروفون وحده كما كان، ونعيد المحاولة عند العودة
                if (!cam) throw e;
                ServiceCompat.startForeground(this, Notifier.ID_ONGOING, n, type);
            }
            running = true;
            locks(true);
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        locks(false);
        try { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE); } catch (Exception e) { }
        super.onDestroy();
    }

    // C99: المعالج والواي فاي يبقيان يعملان طوال المكالمة والشاشة مطفأة — كانت المكالمة تنقطع بعد دقائق في الخلفيّة
    private android.os.PowerManager.WakeLock wake;
    private android.net.wifi.WifiManager.WifiLock wifi;
    private void locks(boolean on) {
        try {
            if (on) {
                if (wake == null) {
                    android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                    wake = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "sawa:call");
                    wake.setReferenceCounted(false);
                    wake.acquire(4 * 3600 * 1000L);
                }
                if (wifi == null) {
                    android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                    if (wm != null) {
                        wifi = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY : android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sawa:call");
                        wifi.setReferenceCounted(false);
                        wifi.acquire();
                    }
                }
            } else {
                if (wake != null) { try { wake.release(); } catch (Throwable t) { } wake = null; }
                if (wifi != null) { try { wifi.release(); } catch (Throwable t) { } wifi = null; }
            }
        } catch (Throwable t) { }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
