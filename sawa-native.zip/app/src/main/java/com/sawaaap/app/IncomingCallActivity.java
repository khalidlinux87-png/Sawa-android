package com.sawaaap.app;

import android.app.Activity;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.ref.WeakReference;

/** شاشة المكالمة الواردة بملء الشاشة — تظهر فوق قفل الهاتف. النغمة من إشعار المكالمة نفسه (تتكرّر حتى الردّ أو الرفض). */
public class IncomingCallActivity extends Activity {
    private static WeakReference<IncomingCallActivity> current = new WeakReference<>(null);
    private String callId = "";
    private final Handler h = new Handler(Looper.getMainLooper());

    static void finishFor(String id) {
        IncomingCallActivity a = current.get();
        if (a != null && id != null && id.equals(a.callId)) a.runOnUiThread(a::finish);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null) km.requestDismissKeyguard(this, null);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent in = getIntent();
        callId = in.getStringExtra("call") == null ? "" : in.getStringExtra("call");
        final boolean en = Notifier.en(this, null);   // C129
        String name = in.getStringExtra("name") == null ? Notifier.tr(en, "سوا", "Sawa") : in.getStringExtra("name");
        boolean video = in.getBooleanExtra("video", false);
        current = new WeakReference<>(this);

        float dp = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.parseColor("#0F3D2C"));
        root.setPadding((int) (24 * dp), (int) (96 * dp), (int) (24 * dp), (int) (48 * dp));
        // C115: الأزرار فوق شريط التنقّل في Android 15/16 (الرسم تحت أشرطة النظام إجباريّ)
        final int pl = (int) (24 * dp), pt = (int) (96 * dp), pb = (int) (48 * dp);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (v, ins) -> {
            androidx.core.graphics.Insets bi = ins.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars());
            v.setPadding(pl + bi.left, pt + bi.top, pl + bi.right, pb + bi.bottom);
            return androidx.core.view.WindowInsetsCompat.CONSUMED;
        });
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.WHITE);
        logo.setBackground(circle);
        logo.setClipToOutline(true);
        int ls = (int) (112 * dp);
        root.addView(logo, new LinearLayout.LayoutParams(ls, ls));

        TextView tn = new TextView(this);
        tn.setText(name);
        tn.setTextColor(Color.WHITE);
        tn.setTextSize(28);
        tn.setTypeface(Typeface.DEFAULT_BOLD);
        tn.setGravity(Gravity.CENTER);
        tn.setPadding(0, (int) (24 * dp), 0, (int) (8 * dp));
        root.addView(tn, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView ts = new TextView(this);
        ts.setText(video ? Notifier.tr(en, "مكالمة فيديو واردة · سوا", "Incoming video call · Sawa") : Notifier.tr(en, "مكالمة صوتيّة واردة · سوا", "Incoming voice call · Sawa"));
        ts.setTextColor(Color.parseColor("#B7E4CF"));
        ts.setTextSize(16);
        ts.setGravity(Gravity.CENTER);
        root.addView(ts, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        Button decline = roundButton(Notifier.tr(en, "رفض", "Decline"), "#D64545", dp);
        Button answer = roundButton(video ? Notifier.tr(en, "ردّ 📹", "Answer 📹") : Notifier.tr(en, "ردّ 📞", "Answer 📞"), "#21A366", dp);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, (int) (64 * dp), 1f);
        bp.setMargins((int) (12 * dp), 0, (int) (12 * dp), 0);
        row.addView(answer, bp);
        row.addView(decline, new LinearLayout.LayoutParams(bp));
        root.addView(row, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        answer.setOnClickListener(v -> {
            try { Notifier.answer(this, callId, Notifier.callNotifId(callId) + 3).send(); } catch (PendingIntent.CanceledException e) { }
            Notifier.stopRinging(this, callId, true);
            finish();
        });
        decline.setOnClickListener(v -> {
            try { CallActionReceiver.pending(this, CallActionReceiver.ACT_DECLINE, callId, Notifier.callNotifId(callId) + 4).send(); } catch (PendingIntent.CanceledException e) { }
            finish();
        });

        setContentView(root);
        // أمانٌ إضافيّ: تُغلق بعد ٥٠ ثانية مهما حدث
        h.postDelayed(() -> { Notifier.stopRinging(this, callId, false); finish(); }, 50000);
    }

    private Button roundButton(String text, String color, float dp) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(18);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(color));
        bg.setCornerRadius(32 * dp);
        b.setBackground(bg);
        return b;
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (current.get() == this) current = new WeakReference<>(null);
        super.onDestroy();
    }
}
