package com.sawaaap.app;

import androidx.annotation.NonNull;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.util.Map;

/** إشعارات FCM الأصليّة — تصل والتطبيق مغلق (أولويّة عالية توقظ الهاتف). */
public class SawaMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        Notifier.prefs(this).edit().putString("fcm", token).apply();
        MainActivity.js("window.__sawaNativeToken&&window.__sawaNativeToken(" + MainActivity.q(token) + ")");
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage msg) {
        Map<String, String> d = msg.getData();
        if (d == null || d.isEmpty()) return;
        String t = Notifier.s(d, "t");

        // التطبيق أمامك: الواجهة نفسها ترنّ/تنبّه (كما في المتصفّح) — نسلّمها البيانات فقط
        if (MainActivity.isForeground()) {
            MainActivity.js("window.__sawaNativePush&&window.__sawaNativePush(" + JSONObject.quote(new JSONObject(d).toString()) + ")");
            if ("test".equals(t)) Notifier.message(this, d, "");
            return;
        }
        if ("call".equals(t)) Notifier.ringIncoming(this, d);
        else if ("missed".equals(t)) Notifier.missed(this, d);
        else Notifier.message(this, d, "رسالة جديدة");
    }
}
