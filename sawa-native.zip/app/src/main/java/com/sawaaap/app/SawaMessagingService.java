package com.sawaaap.app;

import android.app.NotificationManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.util.Map;

/** إشعارات FCM الأصليّة — تصل والتطبيق مغلق (أولويّة عالية توقظ الهاتف). */
public class SawaMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        Notifier.prefs(this).edit().putString("fcm", token).apply();
        MainActivity.js("window.__sawaNativeToken&&window.__sawaNativeToken(" + MainActivity.q(token) + ")");
    }

    static final String ACK_URL = "https://sawa-deploy-test.khalidlinux87.workers.dev/ack";

    /** C111: إقرار الاستلام للخادم بتوقيعه هو (rk/dk في الإشعار) — لا يحتاج رمز دخول. */
    private static void ack(Map<String, String> d, String t) {
        try {
            final JSONObject b = new JSONObject();
            String to = Notifier.s(d, "to");
            if (to == null || to.isEmpty()) return;
            if ("call".equals(t) && !Notifier.s(d, "rk").isEmpty()) {
                b.put("k", "r").put("call", Notifier.s(d, "call")).put("to", to).put("s", Notifier.s(d, "rk"));
            } else if ("msg".equals(t) && !Notifier.s(d, "dk").isEmpty()) {
                b.put("k", "d").put("cid", Notifier.s(d, "cid")).put("to", to).put("ts", Long.parseLong(Notifier.s(d, "ts"))).put("s", Notifier.s(d, "dk"));
            } else return;
            new Thread(() -> {
                java.net.HttpURLConnection c = null;
                try {
                    c = (java.net.HttpURLConnection) new java.net.URL(ACK_URL).openConnection();
                    c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(8000); c.setReadTimeout(8000);
                    c.setRequestProperty("Content-Type", "application/json");
                    byte[] out = b.toString().getBytes("UTF-8");
                    c.getOutputStream().write(out); c.getOutputStream().close();
                    c.getResponseCode();
                } catch (Exception e) { } finally { if (c != null) c.disconnect(); }
            }).start();
        } catch (Exception e) { }
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage msg) {
        Map<String, String> d = msg.getData();
        if (d == null || d.isEmpty()) return;
        String t = Notifier.s(d, "t");
        boolean fg = MainActivity.isForeground();
        // C84: سجلّ الاستلام — «فحص الإشعارات» يعرض آخر ما وصل الهاتف فعلاً (هل يصل والتطبيق مغلق؟)
        try {
            boolean shown = NotificationManagerCompat.from(this).areNotificationsEnabled();
            if (shown && Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                android.app.NotificationChannel ch = nm == null ? null : nm.getNotificationChannel("call".equals(t) ? Notifier.CH_CALLS : Notifier.CH_MSGS);
                if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) shown = false;
            }
            Notifier.prefs(this).edit().putLong("lp_ts", System.currentTimeMillis()).putString("lp_t", t).putBoolean("lp_fg", fg)
                    .putBoolean("lp_shown", fg || shown).putInt("lp_pri", msg.getPriority()).putInt("lp_n", Notifier.prefs(this).getInt("lp_n", 0) + 1).apply();
        } catch (Exception e) { }

        ack(d, t);   // C111: «رنّت» / «وصلت» تصل المرسِل ولو كان التطبيق مغلقاً

        // التطبيق أمامك: الواجهة نفسها ترنّ/تنبّه (كما في المتصفّح) — نسلّمها البيانات فقط
        if (fg) {
            MainActivity.js("window.__sawaNativePush&&window.__sawaNativePush(" + JSONObject.quote(new JSONObject(d).toString()) + ")");
            if ("test".equals(t)) Notifier.message(this, d, "");
            return;
        }
        if ("call".equals(t)) Notifier.ringIncoming(this, d);
        else if ("missed".equals(t)) Notifier.missed(this, d);
        else Notifier.message(this, d, Notifier.tr(Notifier.en(this, d), "رسالة جديدة", "New message"));
    }
}
