package com.sawaaap.app;

import android.app.NotificationManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.util.Map;

/** إشعارات FCM الأصليّة — تصل والتطبيق مغلق (أولويّة عالية توقظ الهاتف). */
public class SawaMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        Notifier.prefs(this).edit().putString("fcm", token).apply();
        MainActivity.js("window.__sawaNativeToken&&window.__sawaNativeToken(" + MainActivity.q(token) + ")");
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage msg) {
        Map<String, String> d = msg.getData();
        if (d == null || d.isEmpty()) return;
        String t = Notifier.s(d, "t");
        boolean fg = MainActivity.isForeground();
        // C84: سجلّ الاستلام — «فحص الإشعارات» يعرض آخر ما وصل الهاتف فعلاً (هل يصل والتطبيق مغلق؟)
        try {
            boolean shown = NotificationManagerCompat.from(this).areNotificationsEnabled();
            if (shown && Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                android.app.NotificationChannel ch = nm == null ? null : nm.getNotificationChannel("call".equals(t) ? Notifier.CH_CALLS : Notifier.CH_MSGS);
                if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) shown = false;
            }
            Notifier.prefs(this).edit().putLong("lp_ts", System.currentTimeMillis()).putString("lp_t", t).putBoolean("lp_fg", fg)
                    .putBoolean("lp_shown", fg || shown).putInt("lp_pri", msg.getPriority()).putInt("lp_n", Notifier.prefs(this).getInt("lp_n", 0) + 1).apply();
        } catch (Exception e) { }

        // التطبيق أمامك: الواجهة نفسها ترنّ/تنبّه (كما في المتصفّح) — نسلّمها البيانات فقط
        if (fg) {
            MainActivity.js("window.__sawaNativePush&&window.__sawaNativePush(" + JSONObject.quote(new JSONObject(d).toString()) + ")");
            if ("test".equals(t)) Notifier.message(this, d, "");
            return;
        }
        if ("call".equals(t)) Notifier.ringIncoming(this, d);
        else if ("missed".equals(t)) Notifier.missed(this, d);
        else Notifier.message(this, d, "رسالة جديدة");
    }
}
