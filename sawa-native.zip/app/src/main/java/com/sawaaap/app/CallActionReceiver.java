package com.sawaaap.app;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** أزرار الإشعارات التي لا تفتح التطبيق: «رفض» المكالمة الواردة · «إنهاء» المكالمة الجارية. */
public class CallActionReceiver extends BroadcastReceiver {
    public static final String ACT_DECLINE = "com.sawaaap.app.DECLINE";
    public static final String ACT_HANGUP = "com.sawaaap.app.HANGUP";

    static PendingIntent pending(Context ctx, String action, String callId, int req) {
        Intent i = new Intent(ctx, CallActionReceiver.class);
        i.setAction(action);
        i.putExtra("call", callId);
        return PendingIntent.getBroadcast(ctx, req, i, Notifier.flagsImmutable());
    }

    /** C142: «رفض» للخادم مباشرةً بتوقيعه (rk) المحفوظ من إشعار الرنين — لا يحتاج التطبيق مفتوحاً ولا رمز دخول. */
    static void declineAck(Context ctx, String callId, final PendingResult pr) {
        android.content.SharedPreferences p = Notifier.prefs(ctx);
        final String rk = callId == null ? "" : p.getString("rk_" + callId, ""), to = callId == null ? "" : p.getString("rto_" + callId, "");
        if (rk.isEmpty() || to.isEmpty()) { if (pr != null) pr.finish(); return; }
        p.edit().remove("rk_" + callId).remove("rto_" + callId).apply();
        new Thread(() -> {
            java.net.HttpURLConnection c = null;
            try {
                org.json.JSONObject b = new org.json.JSONObject().put("k", "x").put("call", callId).put("to", to).put("s", rk);
                c = (java.net.HttpURLConnection) new java.net.URL(SawaMessagingService.ACK_URL).openConnection();
                c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(8000); c.setReadTimeout(8000);
                c.setRequestProperty("Content-Type", "application/json");
                c.getOutputStream().write(b.toString().getBytes("UTF-8")); c.getOutputStream().close();
                c.getResponseCode();
            } catch (Exception e) { } finally { if (c != null) c.disconnect(); if (pr != null) pr.finish(); }
        }).start();
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        String callId = intent.getStringExtra("call");
        if (ACT_DECLINE.equals(a)) {
            Notifier.stopRinging(ctx, callId, true);
            declineAck(ctx, callId, goAsync());   // C142: المتّصل يعرف فوراً أنّها رُفضت ولو كان التطبيق مغلقاً
            // إن كان التطبيق حيّاً نُبلغ الواجهة فترفض المكالمة فعلاً (وإلا ينتهي الرنين عند المتّصل بمهلته)
            MainActivity.js("window.__sawaNativeDecline&&window.__sawaNativeDecline(" + MainActivity.q(callId) + ")");
        } else if (ACT_HANGUP.equals(a)) {
            MainActivity.js("window.__sawaNativeHangup&&window.__sawaNativeHangup()");
            CallService.stop(ctx);
        }
    }
}
