package com.sawaaap.app;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** أزرار الإشعارات التي لا تفتح التطبيق: «رفض» المكالمة الواردة · «إنهاء» المكالمة الجارية. */
public class CallActionReceiver extends BroadcastReceiver {
    public static final String ACT_DECLINE = "com.sawaaap.app.DECLINE";
    public static final String ACT_HANGUP = "com.sawaaap.app.HANGUP";

    static PendingIntent pending(Context ctx, String action, String callId, int req) {
        Intent i = new Intent(ctx, CallActionReceiver.class);
        i.setAction(action);
        i.putExtra("call", callId);
        return PendingIntent.getBroadcast(ctx, req, i, Notifier.flagsImmutable());
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        String callId = intent.getStringExtra("call");
        if (ACT_DECLINE.equals(a)) {
            Notifier.stopRinging(ctx, callId, true);
            // إن كان التطبيق حيّاً نُبلغ الواجهة فترفض المكالمة فعلاً (وإلا ينتهي الرنين عند المتّصل بمهلته)
            MainActivity.js("window.__sawaNativeDecline&&window.__sawaNativeDecline(" + MainActivity.q(callId) + ")");
        } else if (ACT_HANGUP.equals(a)) {
            MainActivity.js("window.__sawaNativeHangup&&window.__sawaNativeHangup()");
            CallService.stop(ctx);
        }
    }
}
