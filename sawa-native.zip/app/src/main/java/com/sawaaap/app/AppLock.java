package com.sawaaap.app;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

/**
 * C73: قفل التطبيق بالبصمة أو قفل شاشة الهاتف (رمز/نمط).
 * - يُقفل عند التشغيل، وبعد البقاء في الخلفيّة المدّة المختارة (فوراً/دقيقة/٥/٣٠ دقيقة).
 * - لا يُقفل أثناء مكالمة جارية، ولا عند الردّ على مكالمة (يُقفل بعد انتهائها).
 * - الواجهة تبقى تعمل تحت الغطاء (المكالمات والرسائل لا تتوقّف)، والغطاء يُخفي المحتوى فقط.
 */
final class AppLock {
    static final int AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL;

    private final MainActivity act;
    private View cover;
    private boolean prompting = false;
    private long errAt = -100000;
    private boolean unlockedThisProcess = false;
    private long hiddenAt = 0;          // elapsedRealtime لحظة الخروج إلى الخلفيّة
    boolean callBypass = false;         // ردٌّ على مكالمة: لا قفل حتّى تنتهي
    boolean suppressNextStop = false;   // نشاطٌ فتحناه نحن (اختيار ملف/تأكيد الرمز) ليس خروجاً

    AppLock(MainActivity a) { act = a; }

    private SharedPreferences p() { return Notifier.prefs(act); }
    boolean enabled() { return p().getBoolean("lock_on", false); }
    long afterMs() { return p().getLong("lock_after", 60000L); }

    boolean available() {
        try {
            if (BiometricManager.from(act).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS) return true;
        } catch (Exception e) { }
        try {
            KeyguardManager km = (KeyguardManager) act.getSystemService(Context.KEYGUARD_SERVICE);
            return km != null && km.isDeviceSecure();
        } catch (Exception e) { return false; }
    }

    String stateJson(String err) {
        try {
            JSONObject o = new JSONObject();
            o.put("available", available());
            o.put("on", enabled());
            o.put("after", afterMs());
            o.put("locked", cover != null);
            if (err != null) o.put("error", err);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    // ---------- دورة حياة النشاط ----------
    void onCreate() { applyRecents(); if (enabled()) showCover(); }

    void onStop() {
        if (suppressNextStop || prompting) { suppressNextStop = false; return; }
        hiddenAt = SystemClock.elapsedRealtime();
        // «فوراً»: الغطاء يوضع الآن كي لا يظهر المحتوى لحظة العودة
        if (enabled() && afterMs() == 0 && !inCall()) showCover();
    }

    void onResume() {
        if (!enabled()) { hideCover(); return; }
        if (cover == null && needsLock()) showCover();
        // بعد إلغاء النافذة لا نعيد فتحها تلقائيّاً (كي لا تدور حلقة) — زرّ «فتح القفل» يبقى
        if (cover != null && !prompting && SystemClock.elapsedRealtime() - errAt > 2500) act.getWindow().getDecorView().post(this::prompt);
    }

    private boolean inCall() { return CallService.running || callBypass; }

    private boolean needsLock() {
        if (inCall()) return false;
        if (!unlockedThisProcess) return true;
        return hiddenAt > 0 && SystemClock.elapsedRealtime() - hiddenAt >= afterMs();
    }

    /** انتهت المكالمة التي فُتح لها التطبيق بلا قفل ⇒ يُقفل الآن إن لزم. */
    void callEnded() {
        if (!callBypass) return;
        callBypass = false;
        if (enabled() && !unlockedThisProcess) { showCover(); if (MainActivity.isForeground()) prompt(); }
    }

    boolean isCovering() { return cover != null; }

    private void applyRecents() {
        if (Build.VERSION.SDK_INT >= 33) { try { act.setRecentsScreenshotEnabled(!enabled()); } catch (Exception e) { } }
    }

    // ---------- الغطاء ----------
    private void showCover() {
        if (cover != null || callBypass) return;
        FrameLayout root = act.root();
        if (root == null) return;
        float dp = act.getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.WHITE);
        box.setClickable(true);   // لا يمرّ اللمس إلى الواجهة تحته
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView logo = new ImageView(act);
        logo.setImageResource(R.drawable.sawa_logo);
        box.addView(logo, new LinearLayout.LayoutParams((int) (96 * dp), (int) (96 * dp)));

        TextView t = new TextView(act);
        t.setText("سوا مقفل");
        t.setTextColor(0xFF1F2D3D);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lt = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lt.setMargins(0, (int) (18 * dp), 0, (int) (6 * dp));
        box.addView(t, lt);

        TextView s = new TextView(act);
        s.setText("استخدم البصمة أو قفل الشاشة لفتحه");
        s.setTextColor(0xFF6B7A8C);
        s.setTextSize(14);
        s.setGravity(Gravity.CENTER);
        box.addView(s, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView b = new TextView(act);
        b.setText("فتح القفل");
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(ContextCompat.getColor(act, R.color.sawa_primary));
        bg.setCornerRadius(24 * dp);
        b.setBackground(bg);
        b.setPadding((int) (36 * dp), (int) (12 * dp), (int) (36 * dp), (int) (12 * dp));
        b.setOnClickListener(v -> prompt());
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lb.setMargins(0, (int) (28 * dp), 0, 0);
        box.addView(b, lb);

        root.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        cover = box;
        MainActivity.js("window.__sawaNativeLock&&window.__sawaNativeLock(" + stateJson(null) + ")");
    }

    private void hideCover() {
        if (cover == null) return;
        FrameLayout root = act.root();
        if (root != null) root.removeView(cover);
        cover = null;
        MainActivity.js("window.__sawaNativeLock&&window.__sawaNativeLock(" + stateJson(null) + ")");
    }

    // ---------- التحقّق ----------
    interface Done { void done(boolean ok, String err); }

    private void prompt() {
        if (cover == null || prompting || !MainActivity.isForeground()) return;
        authenticate("فتح سوا", (ok, err) -> {
            if (ok) { unlockedThisProcess = true; hiddenAt = 0; hideCover(); }
            else errAt = SystemClock.elapsedRealtime();
        });
    }

    void authenticate(String title, Done cb) {
        if (prompting) { cb.done(false, "busy"); return; }
        if (!available()) {
            // أُزيل قفل الشاشة من الهاتف ⇒ لا وسيلة للتحقّق: نُلغي القفل كي لا يُحبس صاحبه خارج التطبيق
            if (enabled()) { p().edit().putBoolean("lock_on", false).apply(); applyRecents(); unlockedThisProcess = true; hideCover(); }
            cb.done(false, "no-screen-lock");
            return;
        }
        prompting = true;
        try {
            BiometricPrompt bp = new BiometricPrompt(act, ContextCompat.getMainExecutor(act), new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult r) { prompting = false; cb.done(true, null); }
                @Override public void onAuthenticationError(int code, @NonNull CharSequence msg) { prompting = false; cb.done(false, "e" + code + ": " + msg); }
                @Override public void onAuthenticationFailed() { /* محاولةٌ خاطئة — النافذة تبقى مفتوحة */ }
            });
            BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle("البصمة أو رمز قفل الهاتف")
                    .setAllowedAuthenticators(AUTH)
                    .build();
            bp.authenticate(info);
        } catch (Exception e) {
            prompting = false;
            cb.done(false, String.valueOf(e));
        }
    }

    /** تفعيل/إيقاف/تغيير المدّة — كلّها تتطلّب التحقّق من صاحب الهاتف أوّلاً. */
    void set(final boolean on, final long after, final Done cb) {
        if (on && !available()) { cb.done(false, "no-screen-lock"); return; }
        if (!on && !enabled()) { cb.done(true, null); return; }
        authenticate(on ? "تفعيل قفل سوا" : "إيقاف قفل سوا", (ok, err) -> {
            if (ok) {
                p().edit().putBoolean("lock_on", on).putLong("lock_after", Math.max(0, after)).apply();
                unlockedThisProcess = true;
                hiddenAt = 0;
                applyRecents();
            }
            cb.done(ok, err);
        });
    }
}
