package com.sawaaap.app;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.DataChannel;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RTCStats;
import org.webrtc.RTCStatsReport;
import org.webrtc.RtpReceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.audio.JavaAudioDeviceModule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * C95: محرّك المكالمات الصوتيّة الأصليّ (مكتبة WebRTC داخل التطبيق بدل WebView).
 * السبب: مخزن الصوت في WebView يتضخّم حتّى ١٫٥–٢ ثانية على شبكات الجوّال المتقلّبة ولا يمكن تحديد سقفٍ له من JS.
 * هنا: سقف المخزن (audioJitterBufferMaxPackets) + تسريع تفريغه (FastAccelerate) + مُلغي صدى العتاد.
 * الإشارات (العرض/الردّ/المرشّحون) تبقى في JS كما هي — JS يستعمل كائناً بديلاً لـRTCPeerConnection يكلّم هذا الصنف.
 * الأحداث تعود إلى window.__sawaRtcEv(id, kind, json) · الردود إلى window.__sawaRtcCb(cb, ok, json).
 */
final class NativeRtc {
    private static final String TAG = "SawaRtc";
    /** ٢٥ حزمة × ٢٠ مللي ث = نصف ثانية حدّاً أعلى (الافتراضيّ في المتصفّح ٢٠٠ حزمة = ٤ ثوانٍ). */
    static final int JB_MAX_PACKETS = 25;

    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static PeerConnectionFactory factory;
    private static JavaAudioDeviceModule adm;
    private static boolean muted = false;

    private static final class Call {
        PeerConnection pc;
        AudioSource src;
        AudioTrack track;
    }
    private static final Map<String, Call> CALLS = new HashMap<>();

    private NativeRtc() { }

    // ---------- أدوات ----------
    private static void ev(String id, String kind, String json) {
        MainActivity.js("window.__sawaRtcEv&&window.__sawaRtcEv(" + MainActivity.q(id) + "," + MainActivity.q(kind) + "," + (json == null ? "null" : json) + ")");
    }
    private static void cb(String cb, boolean ok, String json) {
        if (cb == null || cb.isEmpty()) return;
        MainActivity.js("window.__sawaRtcCb&&window.__sawaRtcCb(" + MainActivity.q(cb) + "," + ok + "," + (json == null ? "null" : json) + ")");
    }
    private static String err(Object m) { return JSONObject.quote(String.valueOf(m)); }
    private static String lower(Object e) { return String.valueOf(e).toLowerCase(java.util.Locale.ROOT); }

    private static void ensureFactory(Context ctx) {
        if (factory != null) return;
        Context app = ctx.getApplicationContext();
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions());
        adm = JavaAudioDeviceModule.builder(app)
                .setUseHardwareAcousticEchoCanceler(true)
                .setUseHardwareNoiseSuppressor(true)
                .createAudioDeviceModule();
        factory = PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory();
    }

    private static List<PeerConnection.IceServer> iceServers(String json) throws Exception {
        List<PeerConnection.IceServer> out = new ArrayList<>();
        JSONArray a = new JSONArray(json == null || json.isEmpty() ? "[]" : json);
        for (int i = 0; i < a.length(); i++) {
            JSONObject s = a.getJSONObject(i);
            List<String> urls = new ArrayList<>();
            Object u = s.opt("urls");
            if (u instanceof JSONArray) { JSONArray ua = (JSONArray) u; for (int k = 0; k < ua.length(); k++) urls.add(ua.getString(k)); }
            else if (u != null) urls.add(String.valueOf(u));
            if (urls.isEmpty()) continue;
            PeerConnection.IceServer.Builder b = PeerConnection.IceServer.builder(urls);
            if (s.has("username")) b.setUsername(s.optString("username"));
            if (s.has("credential")) b.setPassword(s.optString("credential"));
            out.add(b.createIceServer());
        }
        return out;
    }

    private static Call call(String id) { synchronized (CALLS) { return CALLS.get(id); } }

    // ---------- الواجهة (من الجسر) ----------
    static void create(final Context ctx, final String id, final String iceJson, final String cbId) {
        EX.execute(() -> {
            try {
                ensureFactory(ctx);
                PeerConnection.RTCConfiguration cfg = new PeerConnection.RTCConfiguration(iceServers(iceJson));
                cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
                cfg.bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE;
                cfg.rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE;
                cfg.continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY;
                cfg.audioJitterBufferMaxPackets = JB_MAX_PACKETS;
                cfg.audioJitterBufferFastAccelerate = true;
                final Call c = new Call();
                c.pc = factory.createPeerConnection(cfg, new Obs(id));
                if (c.pc == null) throw new IllegalStateException("createPeerConnection");
                synchronized (CALLS) { CALLS.put(id, c); }
                cb(cbId, true, null);
            } catch (Throwable t) {
                Log.w(TAG, "create", t);
                cb(cbId, false, err(t));
            }
        });
    }

    static void addAudio(final String id) {
        EX.execute(() -> {
            Call c = call(id); if (c == null || c.track != null) return;
            try {
                MediaConstraints mc = new MediaConstraints();
                mc.mandatory.add(new MediaConstraints.KeyValuePair("googEchoCancellation", "true"));
                mc.mandatory.add(new MediaConstraints.KeyValuePair("googAutoGainControl", "true"));
                mc.mandatory.add(new MediaConstraints.KeyValuePair("googNoiseSuppression", "true"));
                mc.mandatory.add(new MediaConstraints.KeyValuePair("googHighpassFilter", "true"));
                c.src = factory.createAudioSource(mc);
                c.track = factory.createAudioTrack("a-" + id, c.src);
                c.track.setEnabled(!muted);
                c.pc.addTrack(c.track, Collections.singletonList("s-" + id));
            } catch (Throwable t) { Log.w(TAG, "addAudio", t); }
        });
    }

    static void createSdp(final String id, final boolean offer, final boolean iceRestart, final String cbId) {
        EX.execute(() -> {
            Call c = call(id); if (c == null) { cb(cbId, false, err("closed")); return; }
            MediaConstraints mc = new MediaConstraints();
            mc.mandatory.add(new MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"));
            mc.mandatory.add(new MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"));
            if (iceRestart) mc.mandatory.add(new MediaConstraints.KeyValuePair("IceRestart", "true"));
            SdpObserver o = new Sdp(cbId);
            if (offer) c.pc.createOffer(o, mc); else c.pc.createAnswer(o, mc);
        });
    }

    static void setSdp(final String id, final boolean local, final String type, final String sdp, final String cbId) {
        EX.execute(() -> {
            Call c = call(id); if (c == null) { cb(cbId, false, err("closed")); return; }
            try {
                SessionDescription d = new SessionDescription(SessionDescription.Type.fromCanonicalForm(type), sdp);
                if (local) c.pc.setLocalDescription(new Sdp(cbId), d); else c.pc.setRemoteDescription(new Sdp(cbId), d);
            } catch (Throwable t) { cb(cbId, false, err(t)); }
        });
    }

    static void addIce(final String id, final String json) {
        EX.execute(() -> {
            Call c = call(id); if (c == null) return;
            try {
                JSONObject j = new JSONObject(json);
                String cand = j.optString("candidate", "");
                if (cand.isEmpty()) return;
                c.pc.addIceCandidate(new IceCandidate(j.optString("sdpMid", "0"), j.optInt("sdpMLineIndex", 0), cand));
            } catch (Throwable t) { Log.w(TAG, "addIce", t); }
        });
    }

    static void stats(final String id, final String cbId) {
        EX.execute(() -> {
            Call c = call(id); if (c == null) { cb(cbId, false, err("closed")); return; }
            c.pc.getStats((RTCStatsReport rep) -> {
                try {
                    JSONObject out = new JSONObject();
                    for (Map.Entry<String, RTCStats> e : rep.getStatsMap().entrySet()) {
                        RTCStats s = e.getValue();
                        JSONObject o = new JSONObject();
                        o.put("id", s.getId()); o.put("type", s.getType());
                        for (Map.Entry<String, Object> m : s.getMembers().entrySet()) {
                            Object v = m.getValue();
                            if (v instanceof java.math.BigInteger) v = ((java.math.BigInteger) v).doubleValue();
                            o.put(m.getKey(), JSONObject.wrap(v));
                        }
                        out.put(e.getKey(), o);
                    }
                    cb(cbId, true, out.toString());
                } catch (Throwable t) { cb(cbId, false, err(t)); }
            });
        });
    }

    static void setMuted(final boolean m) {
        EX.execute(() -> {
            muted = m;
            synchronized (CALLS) { for (Call c : CALLS.values()) { try { if (c.track != null) c.track.setEnabled(!m); } catch (Throwable t) { } } }
        });
    }

    static void close(final String id) {
        EX.execute(() -> {
            Call c; synchronized (CALLS) { c = CALLS.remove(id); }
            if (c == null) return;
            try { c.pc.dispose(); } catch (Throwable t) { Log.w(TAG, "dispose", t); }
            try { if (c.src != null) c.src.dispose(); } catch (Throwable t) { }
            synchronized (CALLS) { if (CALLS.isEmpty()) muted = false; }
        });
    }

    // ---------- المراقبون ----------
    private static final class Sdp implements SdpObserver {
        final String cbId;
        Sdp(String cbId) { this.cbId = cbId; }
        public void onCreateSuccess(SessionDescription d) {
            try { JSONObject o = new JSONObject(); o.put("type", d.type.canonicalForm()); o.put("sdp", d.description); cb(cbId, true, o.toString()); }
            catch (Throwable t) { cb(cbId, false, err(t)); }
        }
        public void onSetSuccess() { cb(cbId, true, null); }
        public void onCreateFailure(String e) { cb(cbId, false, err(e)); }
        public void onSetFailure(String e) { cb(cbId, false, err(e)); }
    }

    private static final class Obs implements PeerConnection.Observer {
        final String id;
        Obs(String id) { this.id = id; }
        public void onSignalingChange(PeerConnection.SignalingState s) { }
        public void onIceConnectionChange(PeerConnection.IceConnectionState s) { ev(id, "ice", JSONObject.quote(lower(s))); }
        public void onConnectionChange(PeerConnection.PeerConnectionState s) { ev(id, "conn", JSONObject.quote(lower(s))); }
        public void onIceConnectionReceivingChange(boolean b) { }
        public void onIceGatheringChange(PeerConnection.IceGatheringState s) {
            if (s == PeerConnection.IceGatheringState.COMPLETE) ev(id, "cand", null);
        }
        public void onIceCandidate(IceCandidate c) {
            try { JSONObject o = new JSONObject(); o.put("candidate", c.sdp); o.put("sdpMid", c.sdpMid); o.put("sdpMLineIndex", c.sdpMLineIndex); ev(id, "cand", o.toString()); }
            catch (Throwable t) { }
        }
        public void onIceCandidatesRemoved(IceCandidate[] c) { }
        public void onAddStream(MediaStream s) { }
        public void onRemoveStream(MediaStream s) { }
        public void onDataChannel(DataChannel d) { }
        public void onRenegotiationNeeded() { }
        public void onAddTrack(RtpReceiver r, MediaStream[] s) { ev(id, "track", null); }
    }
}
