package com.sawaaap.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.Person;

import java.util.Map;

/** قنوات الإشعارات وعرضها: المكالمة الواردة (رنينٌ متكرّر بملء الشاشة) · المكالمة الجارية · الرسائل. */
public final class Notifier {
    public static final String CH_CALLS = "sawa_calls_v1";
    public static final String CH_ONGOING = "sawa_ongoing_v1";
    public static final String CH_MSGS = "sawa_messages_v1";
    public static final int ID_ONGOING = 7001;
    static final String PREFS = "sawa";

    private Notifier() {}

    public static void channels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        NotificationChannel calls = new NotificationChannel(CH_CALLS, "المكالمات الواردة", NotificationManager.IMPORTANCE_HIGH);
        calls.setDescription("رنين المكالمات الواردة");
        Uri ring = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        calls.setSound(ring, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        calls.enableVibration(true);
        calls.setVibrationPattern(new long[]{0, 800, 600, 800, 600});
        calls.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        calls.setBypassDnd(false);
        nm.createNotificationChannel(calls);

        NotificationChannel ongoing = new NotificationChannel(CH_ONGOING, "المكالمة الجارية", NotificationManager.IMPORTANCE_LOW);
        ongoing.setDescription("تُبقي المكالمة حيّةً حين تخرج من التطبيق");
        ongoing.setSound(null, null);
        nm.createNotificationChannel(ongoing);

        NotificationChannel msgs = new NotificationChannel(CH_MSGS, "الرسائل", NotificationManager.IMPORTANCE_HIGH);
        msgs.setDescription("الرسائل والطلبات");
        msgs.enableVibration(true);
        nm.createNotificationChannel(msgs);
    }

    static int flagsImmutable() { return PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE; }

    static PendingIntent openUrl(Context ctx, String url, int req) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, req, i, flagsImmutable());
    }

    /** «ردّ»: يفتح التطبيق مباشرةً (أندرويد ١٢+ يمنع فتح نشاطٍ عبر مستقبِلٍ وسيط) ومعه رقم المكالمة ليقبلها تلقائيّاً. */
    static PendingIntent answer(Context ctx, String callId, int req) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://www.sawaaap.com/?call=" + Uri.encode(callId) + "&answer=1"));
        i.putExtra("answer_call", callId);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, req, i, flagsImmutable());
    }

    static String s(Map<String, String> d, String k) { String v = d.get(k); return v == null ? "" : v; }

    static SharedPreferences prefs(Context ctx) { return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static int callNotifId(String callId) { return 5000 + (callId.hashCode() & 0x0fff); }

    /** مكالمة واردة: إشعار مكالمة (CallStyle) + شاشة كاملة فوق القفل + نغمة الرنين تتكرّر حتى الردّ/الرفض/انتهاء المهلة. */
    public static void ringIncoming(Context ctx, Map<String, String> d) {
        String callId = s(d, "call");
        if (callId.isEmpty()) return;
        SharedPreferences p = prefs(ctx);
        // تكرار الخادم كلّ ٨ ثوانٍ: إن كانت ترنّ أصلاً أو رفضناها أو أُجيبت ⇒ لا شيء
        if (p.getBoolean("done_" + callId, false)) return;
        if (callId.equals(p.getString("ringing", ""))) return;
        p.edit().putString("ringing", callId).apply();

        channels(ctx);
        String name = s(d, "title").isEmpty() ? "سوا" : s(d, "title");
        boolean video = "video".equals(s(d, "type"));
        int nid = callNotifId(callId);

        Intent full = new Intent(ctx, IncomingCallActivity.class);
        full.putExtra("call", callId);
        full.putExtra("name", name);
        full.putExtra("video", video);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        PendingIntent fullPi = PendingIntent.getActivity(ctx, nid, full, flagsImmutable());

        PendingIntent answerPi = answer(ctx, callId, nid + 1);
        PendingIntent declinePi = CallActionReceiver.pending(ctx, CallActionReceiver.ACT_DECLINE, callId, nid + 2);

        Person caller = new Person.Builder().setName(name).setImportant(true).build();
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CH_CALLS)
                .setSmallIcon(R.drawable.ic_stat_sawa)
                .setContentTitle(name)
                .setContentText(video ? "📹 مكالمة فيديو واردة" : "📞 مكالمة صوتيّة واردة")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setTimeoutAfter(50000)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(fullPi)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(caller, declinePi, answerPi));
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;   // النغمة تتكرّر حتى يُزال الإشعار
        notify(ctx, nid, n);
    }

    /** أوقف الرنين (ردّ/رفض/ألغاها المتّصل). */
    public static void stopRinging(Context ctx, String callId, boolean done) {
        if (callId == null || callId.isEmpty()) return;
        SharedPreferences p = prefs(ctx);
        SharedPreferences.Editor e = p.edit();
        if (callId.equals(p.getString("ringing", ""))) e.remove("ringing");
        if (done) e.putBoolean("done_" + callId, true);
        e.apply();
        NotificationManagerCompat.from(ctx).cancel(callNotifId(callId));
        IncomingCallActivity.finishFor(callId);
    }

    public static void missed(Context ctx, Map<String, String> d) {
        String callId = s(d, "call");
        stopRinging(ctx, callId, true);
        message(ctx, d, "📞 مكالمة فائتة");
    }

    /** رسالة/طلب/اختبار: إشعارٌ عاديّ بصوت القناة، والنقر يفتح المحادثة. */
    public static void message(Context ctx, Map<String, String> d, String fallbackBody) {
        channels(ctx);
        String t = s(d, "t"), cid = s(d, "cid");
        String title = s(d, "title").isEmpty() ? "سوا" : s(d, "title");
        String body = s(d, "body").isEmpty() ? fallbackBody : s(d, "body");
        String url = "https://www.sawaaap.com/";
        if ("req".equals(t)) url += "?requests=1";
        else if (!cid.isEmpty()) url += "?chat=" + Uri.encode(cid);
        int nid = 3000 + ((cid.isEmpty() ? t : cid).hashCode() & 0x0fff);
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CH_MSGS)
                .setSmallIcon(R.drawable.ic_stat_sawa)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(openUrl(ctx, url, nid));
        notify(ctx, nid, b.build());
    }

    /** إشعار «مكالمة جارية» الثابت (تستعمله CallService). */
    public static Notification ongoing(Context ctx, String title) {
        channels(ctx);
        PendingIntent back = openUrl(ctx, "https://www.sawaaap.com/", ID_ONGOING);
        PendingIntent end = CallActionReceiver.pending(ctx, CallActionReceiver.ACT_HANGUP, "", ID_ONGOING + 1);
        return new NotificationCompat.Builder(ctx, CH_ONGOING)
                .setSmallIcon(R.drawable.ic_stat_sawa)
                .setContentTitle(title == null || title.isEmpty() ? "مكالمة جارية" : title)
                .setContentText("مكالمة جارية في سوا — اضغط للعودة")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setUsesChronometer(true)
                .setWhen(System.currentTimeMillis())
                .setContentIntent(back)
                .addAction(0, "العودة", back)
                .addAction(0, "إنهاء", end)
                .build();
    }

    static void notify(Context ctx, int id, Notification n) {
        try { NotificationManagerCompat.from(ctx).notify(id, n); } catch (SecurityException e) { /* لا إذن إشعارات */ }
    }
}
