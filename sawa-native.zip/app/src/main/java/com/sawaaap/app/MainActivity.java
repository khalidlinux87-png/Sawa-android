package com.sawaaap.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.RenderProcessGoneDetail;
import android.os.PowerManager;
import android.provider.Settings;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/** سوا: واجهة www.sawaaap.com داخل WebView + جسرٌ أصليّ (SawaNativeBridge) للإشعارات والمكالمات والدخول بـGoogle. */
public class MainActivity extends AppCompatActivity {
    private static WeakReference<MainActivity> inst = new WeakReference<>(null);
    private static volatile boolean foreground = false;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int RC_MEDIA = 11, RC_NOTIF = 12, RC_GEO = 13, RC_FILE = 21;

    private WebView web;
    private FrameLayout root;
    AppLock lock;
    private boolean pageReady = false;
    private PermissionRequest pendingMedia;
    private GeolocationPermissions.Callback pendingGeoCb;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> fileCb;

    static boolean isForeground() { return foreground && inst.get() != null; }

    /** تنفيذ JS في الواجهة من أيّ خيط (يُتجاهل إن لم يكن التطبيق حيّاً). */
    static void js(final String code) {
        MAIN.post(() -> {
            MainActivity a = inst.get();
            if (a != null && a.web != null) a.web.evaluateJavascript(code, null);
        });
    }

    static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        inst = new WeakReference<>(this);
        Notifier.channels(this);

        web = new WebView(this);
        root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        lock = new AppLock(this);
        Intent first = getIntent();
        if (first != null && first.getStringExtra("answer_call") != null) lock.callBypass = true;   // الردّ على مكالمة لا ينتظر القفل
        lock.onCreate();
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setUserAgentString(s.getUserAgentString() + " SawaAndroid/" + BuildConfig.VERSION_NAME);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "SawaNativeBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                String host = u.getHost() == null ? "" : u.getHost();
                if (("https".equals(scheme) || "http".equals(scheme)) && (host.equals("www.sawaaap.com") || host.equals("sawaaap.com"))) return false;
                if (("https".equals(scheme)) && (host.endsWith(".firebaseapp.com") || host.endsWith(".googleapis.com"))) return false;
                openExternal(u.toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
            }

            // C82: إن قتل النظام عارض الصفحة (ذاكرة) كانت الشاشة تبقى سوداء — نعيد بناء النشاط بدل ذلك
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                try { if (web != null) { root.removeView(web); web.destroy(); web = null; } } catch (Exception e) { }
                MAIN.post(MainActivity.this::recreate);
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                MAIN.post(() -> handleMediaPermission(r));
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) { cb.invoke(origin, true, false); return; }
                pendingGeoOrigin = origin; pendingGeoCb = cb;
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, RC_GEO);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                lock.suppressNextStop = true;
                try { startActivityForResult(p.createIntent(), RC_FILE); }
                catch (ActivityNotFoundException e) { fileCb = null; lock.suppressNextStop = false; return false; }
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIF);
        }
        fetchToken();

        String start = urlFrom(getIntent());
        handleAnswerExtra(getIntent());
        web.loadUrl(start != null ? start : BuildConfig.HOME_URL);
    }

    private static String urlFrom(Intent i) {
        if (i == null || i.getData() == null) return null;
        Uri u = i.getData();
        String host = u.getHost() == null ? "" : u.getHost();
        if (!"https".equals(u.getScheme()) || !(host.equals("www.sawaaap.com") || host.equals("sawaaap.com"))) return null;
        return u.toString();
    }

    private void handleAnswerExtra(Intent i) {
        if (i == null) return;
        String ans = i.getStringExtra("answer_call");
        if (ans != null && !ans.isEmpty()) {
            Notifier.stopRinging(this, ans, true);
            if (lock != null && !lock.isCovering()) lock.callBypass = true;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleAnswerExtra(intent);
        String url = urlFrom(intent);
        if (url == null) return;
        if (!pageReady) { web.loadUrl(url); return; }
        // الواجهة تعالج الرابط في مكانها (مكالمة/غرفة/محادثة) بلا إعادة تحميلٍ تقطع مكالمةً جارية
        web.evaluateJavascript("(window.__sawaNativeOpen&&window.__sawaNativeOpen(" + q(url) + "))?1:0", v -> {
            if (!"1".equals(v)) web.loadUrl(url);
        });
    }

    FrameLayout root() { return root; }

    @Override protected void onResume() { super.onResume(); foreground = true; inst = new WeakReference<>(this); if (lock != null) lock.onResume(); }
    @Override protected void onPause() { foreground = false; super.onPause(); }

    @Override
    protected void onStop() {
        super.onStop();
        if (lock != null) {
            if (lock.callBypass && !CallService.running) lock.callBypass = false;
            lock.onStop();
        }
    }

    @Override
    protected void onDestroy() {
        setProximity(false);
        if (inst.get() == this) inst = new WeakReference<>(null);
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (lock != null && lock.isCovering()) { moveTaskToBack(true); return; }
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        moveTaskToBack(true);   // كتطبيقات المكالمات: الرجوع لا يُغلق التطبيق
    }

    // ---------- الأذونات ----------
    private boolean has(String p) { return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED; }

    private void handleMediaPermission(PermissionRequest r) {
        List<String> need = new ArrayList<>();
        for (String res : r.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
        }
        if (need.isEmpty()) { r.grant(r.getResources()); return; }
        if (pendingMedia != null) { try { pendingMedia.deny(); } catch (Exception e) { } }
        pendingMedia = r;
        ActivityCompat.requestPermissions(this, need.toArray(new String[0]), RC_MEDIA);
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == RC_MEDIA && pendingMedia != null) {
            PermissionRequest r = pendingMedia; pendingMedia = null;
            List<String> ok = new ArrayList<>();
            for (String x : r.getResources()) {
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x) && has(Manifest.permission.RECORD_AUDIO)) ok.add(x);
                else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x) && has(Manifest.permission.CAMERA)) ok.add(x);
            }
            if (ok.isEmpty()) r.deny(); else r.grant(ok.toArray(new String[0]));
        } else if (code == RC_GEO && pendingGeoCb != null) {
            boolean g = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION);
            pendingGeoCb.invoke(pendingGeoOrigin, g, false);
            pendingGeoCb = null;
        } else if (code == RC_NOTIF) {
            js("window.__sawaNativePerm&&window.__sawaNativePerm(" + q(notifState()) + ")");
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == RC_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCb = null;
        }
    }

    private String notifState() {
        boolean enabled = NotificationManagerCompat.from(this).areNotificationsEnabled();
        if (enabled && (Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS))) return "granted";
        return Notifier.prefs(this).getBoolean("notif_asked", false) ? "denied" : "default";
    }

    private void fetchToken() {
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                if (!t.isSuccessful() || t.getResult() == null) return;
                String tok = t.getResult();
                Notifier.prefs(this).edit().putString("fcm", tok).apply();
                js("window.__sawaNativeToken&&window.__sawaNativeToken(" + q(tok) + ")");
            });
        } catch (Exception e) { /* Firebase غير مهيّأ */ }
    }

    private PowerManager.WakeLock proxLock;
    boolean proximitySupported() {
        try { PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE); return pm != null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK); }
        catch (Exception e) { return false; }
    }
    void setProximity(boolean on) {
        try {
            if (on) {
                if (proxLock == null && proximitySupported()) {
                    PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                    proxLock = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "sawa:proximity");
                    proxLock.setReferenceCounted(false);
                }
                if (proxLock != null && !proxLock.isHeld()) proxLock.acquire(4 * 60 * 60 * 1000L);
            } else if (proxLock != null && proxLock.isHeld()) {
                proxLock.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY);
            }
        } catch (Exception e) { }
    }

    // C82: صفحات إعدادات الهاتف التي تقرّر هل يصل الإشعار والتطبيق مغلق
    private void openSetting(String kind) {
        String pkg = getPackageName();
        List<Intent> tries = new ArrayList<>();
        if ("battery".equals(kind)) {
            if (Build.VERSION.SDK_INT >= 23) tries.add(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg)));
            tries.add(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } else if ("fullscreen".equals(kind)) {
            if (Build.VERSION.SDK_INT >= 34) tries.add(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + pkg)));
        } else if ("notif".equals(kind)) {
            Intent i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
            i.putExtra("android.provider.extra.APP_PACKAGE", pkg);
            tries.add(i);
        } else if ("calls".equals(kind)) {
            if (Build.VERSION.SDK_INT >= 26) {
                Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
                i.putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH_CALLS);
                tries.add(i);
            }
        } else if ("launch".equals(kind)) {
            // «تشغيل التطبيقات» في Honor/Huawei، و«التشغيل التلقائيّ» في Xiaomi/Oppo/Vivo
            String[][] comps = {
                {"com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"},
            };
            for (String[] c : comps) { Intent i = new Intent(); i.setComponent(new ComponentName(c[0], c[1])); tries.add(i); }
        }
        tries.add(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
        for (Intent i : tries) {
            try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); lock.suppressNextStop = true; startActivity(i); return; } catch (Exception e) { lock.suppressNextStop = false; }
        }
    }

    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { /* لا تطبيق يفتحه */ }
    }

    // ---------- الدخول بـGoogle أصليّاً (Google تمنع الدخول من داخل WebView) ----------
    private void googleSignIn(final String cb) {
        try {
            GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(BuildConfig.WEB_CLIENT_ID).build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            CredentialManager cm = CredentialManager.create(this);
            cm.getCredentialAsync(this, req, new CancellationSignal(), ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override
                        public void onResult(GetCredentialResponse r) {
                            Credential c = r.getCredential();
                            String token = null;
                            if (c instanceof CustomCredential && "com.google.android.libraries.identity.googleid.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL".equals(c.getType())) {
                                token = c.getData().getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_ID_TOKEN");
                            }
                            reply(cb, token != null, token, token != null ? "" : "no-token");
                        }

                        @Override
                        public void onError(@NonNull GetCredentialException e) {
                            reply(cb, false, null, e.getClass().getSimpleName() + ": " + e.getMessage());
                        }
                    });
        } catch (Exception e) {
            reply(cb, false, null, String.valueOf(e));
        }
    }

    private void reply(String cb, boolean ok, String token, String err) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (token != null) o.put("idToken", token);
            if (err != null && !err.isEmpty()) o.put("error", err);
            js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + o.toString() + ")");
        } catch (Exception e) { }
    }

    /** الجسر الذي تراه الواجهة: window.SawaNativeBridge */
    class Bridge {
        @JavascriptInterface public String platform() { return "android/" + BuildConfig.VERSION_NAME; }
        @JavascriptInterface public String fcmToken() { return Notifier.prefs(MainActivity.this).getString("fcm", ""); }
        @JavascriptInterface public String notifPermission() { return notifState(); }

        @JavascriptInterface public void requestNotifPermission() {
            MAIN.post(() -> {
                Notifier.prefs(MainActivity.this).edit().putBoolean("notif_asked", true).apply();
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIF);
                } else if (!NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled()) {
                    // محظورة من الإعدادات ⇒ نفتح صفحة إشعارات التطبيق
                    Intent i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
                    i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                    try { startActivity(i); } catch (Exception e) { }
                } else {
                    js("window.__sawaNativePerm&&window.__sawaNativePerm('granted')");
                }
                fetchToken();
            });
        }

        @JavascriptInterface public void googleSignIn(final String cb) { MAIN.post(() -> MainActivity.this.googleSignIn(cb)); }

        @JavascriptInterface public void setInCall(final boolean on, final String title) {
            MAIN.post(() -> {
                // C82: الشاشة تبقى مضاءة طوال المكالمة (كانت تُطفأ بمهلة الشاشة بعد ثوانٍ فتبدو سوداء)
                try { if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); } catch (Exception e) { }
                if (on) CallService.start(MainActivity.this, title);
                else { CallService.stop(MainActivity.this); setProximity(false); if (lock != null) lock.callEnded(); }
            });
        }

        @JavascriptInterface public void openExternal(final String url) { MAIN.post(() -> MainActivity.this.openExternal(url)); }

        @JavascriptInterface public void callDone(final String callId) { Notifier.stopRinging(MainActivity.this, callId, true); }

        // C82: ما يمنع وصول المكالمات والتطبيق مغلق — للعرض في «فحص الإشعارات» مع أزرار الإصلاح
        @JavascriptInterface public String bgStatus() {
            try {
                JSONObject o = new JSONObject();
                o.put("notif", NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled());
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                    android.app.NotificationChannel ch = nm.getNotificationChannel(Notifier.CH_CALLS);
                    o.put("callsChannel", ch == null ? -1 : ch.getImportance());
                }
                if (Build.VERSION.SDK_INT >= 34 && nm != null) o.put("fullScreen", nm.canUseFullScreenIntent());
                else o.put("fullScreen", true);
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                o.put("battery", Build.VERSION.SDK_INT < 23 || (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())));
                o.put("maker", String.valueOf(Build.MANUFACTURER).toLowerCase());
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("fcm", Notifier.prefs(MainActivity.this).getString("fcm", "").length() > 0);
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        // C82: حسّاس القرب الحقيقيّ في المكالمة الصوتيّة على السمّاعة — الشاشة تنطفئ عند الأذن وتعود حين تبعد الهاتف
        //      (بدل «وضع الأذن» في الويب: شاشةٌ سوداء بعد ٥ ثوانٍ لا تعود إلّا بالضغط المطوّل)
        @JavascriptInterface public boolean setProximity(final boolean on) {
            MAIN.post(() -> MainActivity.this.setProximity(on));
            return proximitySupported();
        }

        @JavascriptInterface public void openSetting(final String kind) {
            MAIN.post(() -> MainActivity.this.openSetting(kind));
        }

        // C73: قفل التطبيق
        @JavascriptInterface public String appLockState() { return lock != null ? lock.stateJson(null) : "{}"; }

        @JavascriptInterface public void setAppLock(final boolean on, final double afterMs, final String cb) {
            MAIN.post(() -> lock.set(on, (long) afterMs, (ok, err) -> {
                try {
                    JSONObject o = new JSONObject(lock.stateJson(null));
                    o.put("ok", ok);
                    if (err != null) o.put("error", err);
                    js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + o.toString() + ")");
                } catch (Exception e) { }
            }));
        }

        // C73: ماسح QR الأصليّ
        @JavascriptInterface public void scanQr(final String cb) {
            MAIN.post(() -> {
                lock.suppressNextStop = true;
                QrScan.start(MainActivity.this, (value, cancelled, err) -> {
                    lock.suppressNextStop = false;
                    try {
                        JSONObject o = new JSONObject();
                        o.put("ok", value != null);
                        if (value != null) o.put("value", value);
                        if (cancelled) o.put("cancelled", true);
                        if (err != null) o.put("error", err);
                        js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + o.toString() + ")");
                    } catch (Exception e) { }
                });
            });
        }
    }
}
