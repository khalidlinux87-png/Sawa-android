package com.sawaaap.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.RenderProcessGoneDetail;
import android.os.PowerManager;
import android.provider.Settings;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.view.Gravity;
import android.graphics.Color;
import android.content.pm.ActivityInfo;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/** سوا: واجهة www.sawaaap.com داخل WebView + جسرٌ أصليّ (SawaNativeBridge) للإشعارات والمكالمات والدخول بـGoogle. */
public class MainActivity extends AppCompatActivity {
    private static WeakReference<MainActivity> inst = new WeakReference<>(null);
    private static volatile boolean foreground = false;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int RC_MEDIA = 11, RC_NOTIF = 12, RC_GEO = 13, RC_CONTACTS = 14, RC_FILE = 21, RC_SCREEN = 31;
    private String pendingContactsCb;

    private WebView web;
    private FrameLayout root;
    AppLock lock;
    private boolean pageReady = false;
    private PermissionRequest pendingMedia;
    private GeolocationPermissions.Callback pendingGeoCb;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> fileCb;

    static volatile String openChat = "";   // C227
    static boolean isOpenChat(String cid) { return cid != null && !cid.isEmpty() && isForeground() && cid.equals(openChat); }
    static boolean isForeground() { return foreground && inst.get() != null; }

    /** تنفيذ JS في الواجهة من أيّ خيط (يُتجاهل إن لم يكن التطبيق حيّاً). */
    static void js(final String code) {
        MAIN.post(() -> {
            MainActivity a = inst.get();
            if (a != null && a.web != null) a.web.evaluateJavascript(code, null);
        });
    }

    static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        inst = new WeakReference<>(this);
        Notifier.channels(this);

        web = new WebView(this);
        root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        edgeToEdge();   // C115: Android 15/16 يرسم التطبيق تحت أشرطة النظام إجباريّاً
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { handleBack(); }   // C115: Android 16 لا يستدعي onBackPressed
        });
        lock = new AppLock(this);
        Intent first = getIntent();
        if (first != null && first.getStringExtra("answer_call") != null) lock.callBypass = true;   // الردّ على مكالمة لا ينتظر القفل
        lock.onCreate();
        MAIN.postDelayed(() -> NativeRtc.warm(MainActivity.this), 3000);   // C113: أوّل مكالمة أسرع
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // C289: التكبير بإصبعين (الصفحة صارت تسمح به) — بلا أزرار +/− على الشاشة
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setUserAgentString(s.getUserAgentString() + " SawaAndroid/" + BuildConfig.VERSION_NAME);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "SawaNativeBridge");
        // C99: عارض الصفحة يبقى «مهمّاً» والتطبيق في الخلفيّة (لا يُخفَّض فيُقتل أو يُجمَّد أثناء مكالمة)
        if (Build.VERSION.SDK_INT >= 26) { try { web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false); } catch (Throwable t) { } }
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                String host = u.getHost() == null ? "" : u.getHost();
                if (("https".equals(scheme) || "http".equals(scheme)) && (host.equals("www.sawaaap.com") || host.equals("sawaaap.com"))) return false;
                if (("https".equals(scheme)) && (host.endsWith(".firebaseapp.com") || host.endsWith(".googleapis.com"))) return false;
                openExternal(u.toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                deliverShare();
            }

            // C82: إن قتل النظام عارض الصفحة (ذاكرة) كانت الشاشة تبقى سوداء — نعيد بناء النشاط بدل ذلك
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                try { if (web != null) { root.removeView(web); web.destroy(); web = null; } } catch (Exception e) { }
                MAIN.post(MainActivity.this::recreate);
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                MAIN.post(() -> handleMediaPermission(r));
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) { cb.invoke(origin, true, false); return; }
                pendingGeoOrigin = origin; pendingGeoCb = cb;
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, RC_GEO);
            }

            // C140: ملء الشاشة للفيديو (زرّ ⛶ في مشغّل الفيديو) — كان WebView يتجاهله لأنّ onShowCustomView غير مُنفَّذ
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (fsView != null) { cb.onCustomViewHidden(); return; }
                fsView = view; fsCb = cb; fsOrient = getRequestedOrientation();
                view.setBackgroundColor(Color.BLACK);
                root.addView(view, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                try {
                    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), view);
                    c.hide(WindowInsetsCompat.Type.systemBars());
                    c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                } catch (Exception ignored) { }
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_USER);   // يدور مع الهاتف (فيديو أفقيّ ⇒ الشاشة كلّها)
            }

            @Override
            public void onHideCustomView() { exitVideoFullscreen(); }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                lock.suppressNextStop = true;
                try { startActivityForResult(FileBridge.chooser(MainActivity.this, p), RC_FILE); }   // C89: كلّ الأنواع + متعدّد + كاميرا
                catch (ActivityNotFoundException e) { fileCb = null; lock.suppressNextStop = false; return false; }
                return true;
            }
        });

        // C348: لا نطلب إذن الإشعارات عند الفتح (قبل الدخول وبلا شرح) — تطلبه الواجهة في خطوة «الإشعارات» بعد الدخول، أو من شريط «فعّل الإشعارات»
        fetchToken();

        String start = urlFrom(getIntent());
        handleAnswerExtra(getIntent());
        if (FileBridge.isShare(getIntent())) importShareAsync(getIntent());   // C89: «مشاركة إلى سوا»
        new Thread(() -> FileBridge.cleanup(this)).start();
        web.loadUrl(start != null ? start : BuildConfig.HOME_URL);
    }

    private static String urlFrom(Intent i) {
        if (i == null || i.getData() == null) return null;
        Uri u = i.getData();
        String host = u.getHost() == null ? "" : u.getHost();
        if (!"https".equals(u.getScheme()) || !(host.equals("www.sawaaap.com") || host.equals("sawaaap.com"))) return null;
        return u.toString();
    }

    private void handleAnswerExtra(Intent i) {
        if (i == null) return;
        String ans = i.getStringExtra("answer_call");
        if (ans != null && !ans.isEmpty()) {
            Notifier.stopRinging(this, ans, true);
            if (lock != null && !lock.isCovering()) lock.callBypass = true;
            overLock(true);   // C142: «ردّ» والهاتف مقفل ⇒ المكالمة تظهر فوق شاشة القفل (كواتساب) بدل طلب فتح القفل أوّلاً
        }
    }
    @SuppressWarnings("deprecation")
    private void overLock(boolean on) {
        try {
            if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(on); setTurnScreenOn(on); }
            else if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        } catch (Exception e) { }
    }

    // ---------- C142: «صورة داخل صورة» لمكالمات الفيديو والغرف ----------
    // الواجهة تبلغنا متى تكون مطلوبة (setPip) ⇒ الخروج من سوا (زرّ الرئيسيّة/تطبيقٌ آخر) يصغّرها نافذةً عائمة فوق التطبيقات الأخرى،
    // والصفحة تعرض فيها صورة المكالمة وحدها (window.__sawaPip). أندرويد ١٢+: تدخلها تلقائيّاً مع إيماءة الرئيسيّة.
    private volatile boolean pipWanted = false;
    private android.app.PictureInPictureParams pipParams() {
        android.app.PictureInPictureParams.Builder b = new android.app.PictureInPictureParams.Builder()
                .setAspectRatio(new android.util.Rational(3, 4));
        if (Build.VERSION.SDK_INT >= 31) { b.setAutoEnterEnabled(pipWanted); b.setSeamlessResizeEnabled(true); }
        return b.build();
    }
    private void setPipWanted(boolean on) {
        pipWanted = on;
        if (Build.VERSION.SDK_INT < 26) return;
        try { if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) setPictureInPictureParams(pipParams()); } catch (Exception e) { }
    }
    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (!pipWanted || Build.VERSION.SDK_INT < 26 || (Build.VERSION.SDK_INT >= 31)) return;   // ١٢+ تلقائيّ (setAutoEnterEnabled)
        try { if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) enterPictureInPictureMode(pipParams()); } catch (Exception e) { }
    }
    @Override
    public void onPictureInPictureModeChanged(boolean inPip, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        if (web != null) web.evaluateJavascript("window.__sawaPip&&window.__sawaPip(" + inPip + ")", null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleAnswerExtra(intent);
        if (FileBridge.isShare(intent)) { importShareAsync(intent); return; }
        String url = urlFrom(intent);
        if (url == null) return;
        if (!pageReady) { web.loadUrl(url); return; }
        // الواجهة تعالج الرابط في مكانها (مكالمة/غرفة/محادثة) بلا إعادة تحميلٍ تقطع مكالمةً جارية
        web.evaluateJavascript("(window.__sawaNativeOpen&&window.__sawaNativeOpen(" + q(url) + "))?1:0", v -> {
            if (!"1".equals(v)) web.loadUrl(url);
        });
    }

    // C89: ما شورِك إلى سوا يُنسخ في خيطٍ خلفيّ ثمّ يُسلَّم للواجهة (أو تأخذه بنفسها عند جاهزيّتها)
    private void importShareAsync(final Intent i) {
        new Thread(() -> {
            String j = FileBridge.importShare(this, i);
            if (j != null) MAIN.post(this::deliverShare);
        }).start();
    }
    private void deliverShare() {
        if (!pageReady || web == null) return;
        web.evaluateJavascript("window.__sawaNativeShareIn?(window.__sawaNativeShareIn(),1):0", v -> { });
    }

    FrameLayout root() { return root; }

    @Override protected void onResume() { super.onResume(); if (CallService.running && CallService.video) CallService.start(this, CallService.lastTitle);   // C291: نوع الكاميرا الذي رفضه النظام في الخلفيّة يُطلب الآن
        foreground = true; inst = new WeakReference<>(this); if (lock != null) lock.onResume(); }
    @Override protected void onPause() { foreground = false; super.onPause(); }

    @Override
    protected void onStop() {
        super.onStop();
        if (lock != null) {
            if (lock.callBypass && !CallService.running) lock.callBypass = false;
            lock.onStop();
        }
    }

    @Override
    protected void onDestroy() {
        vnStopAll();   // C318
        setProximity(false);
        if (inst.get() == this) inst = new WeakReference<>(null);
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    /** C115: الواجهة داخل حدود أشرطة النظام ولوحة المفاتيح (هوامش من insets)، وشريط الحالة بلون سوا. */
    private View statusScrim;
    private void edgeToEdge() {
        try {
            root.setBackgroundColor(ContextCompat.getColor(this, R.color.sawa_bg));
            statusScrim = new View(this);
            statusScrim.setBackgroundColor(ContextCompat.getColor(this, R.color.sawa_primary));
            root.addView(statusScrim, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 0, Gravity.TOP));
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
                if (web != null) {
                    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) web.getLayoutParams();
                    lp.setMargins(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
                    web.setLayoutParams(lp);
                }
                FrameLayout.LayoutParams sp = (FrameLayout.LayoutParams) statusScrim.getLayoutParams();
                sp.height = bars.top; statusScrim.setLayoutParams(sp);
                return WindowInsetsCompat.CONSUMED;
            });
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
            c.setAppearanceLightStatusBars(false);   // أيقونات بيضاء فوق الأزرق
            c.setAppearanceLightNavigationBars(true);
        } catch (Throwable t) { }
    }

    private View fsView;
    private WebChromeClient.CustomViewCallback fsCb;
    private int fsOrient = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private void exitVideoFullscreen() {
        if (fsView == null) return;
        View v = fsView; WebChromeClient.CustomViewCallback cb = fsCb;
        fsView = null; fsCb = null;
        try { root.removeView(v); } catch (Exception ignored) { }
        try { WindowCompat.getInsetsController(getWindow(), web).show(WindowInsetsCompat.Type.systemBars()); } catch (Exception ignored) { }
        setRequestedOrientation(fsOrient);
        if (cb != null) try { cb.onCustomViewHidden(); } catch (Exception ignored) { }
    }
    private void handleBack() {
        if (fsView != null) { exitVideoFullscreen(); return; }   // C140: الرجوع يخرج من ملء الشاشة أوّلاً
        if (lock != null && lock.isCovering()) { moveTaskToBack(true); return; }
        if (web == null) { moveTaskToBack(true); return; }
        // C99: الواجهة أوّلاً — تُغلق الورقة/الشاشة العليا (زرّ «رجوع» فيها). كان الرجوع من شاشةٍ بلا خطوة في السجلّ يُخرج من التطبيق
        web.evaluateJavascript("(function(){try{return window.__sawaBack&&window.__sawaBack()?1:0}catch(e){return 0}})()", v -> {
            if ("1".equals(v)) return;
            if (web != null && web.canGoBack()) { web.goBack(); return; }
            moveTaskToBack(true);   // كتطبيقات المكالمات: الرجوع لا يُغلق التطبيق
        });
    }

    // ---------- الأذونات ----------
    private boolean has(String p) { return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED; }

    private void handleMediaPermission(PermissionRequest r) {
        List<String> need = new ArrayList<>();
        for (String res : r.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
        }
        if (need.isEmpty()) { r.grant(r.getResources()); return; }
        if (pendingMedia != null) { try { pendingMedia.deny(); } catch (Exception e) { } }
        pendingMedia = r;
        ActivityCompat.requestPermissions(this, need.toArray(new String[0]), RC_MEDIA);
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == RC_MEDIA && pendingMedia != null) {
            PermissionRequest r = pendingMedia; pendingMedia = null;
            List<String> ok = new ArrayList<>();
            for (String x : r.getResources()) {
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x) && has(Manifest.permission.RECORD_AUDIO)) ok.add(x);
                else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x) && has(Manifest.permission.CAMERA)) ok.add(x);
            }
            if (ok.isEmpty()) r.deny(); else r.grant(ok.toArray(new String[0]));
        } else if (code == RC_GEO && pendingGeoCb != null) {
            boolean g = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION);
            pendingGeoCb.invoke(pendingGeoOrigin, g, false);
            pendingGeoCb = null;
        } else if (code == RC_CONTACTS && pendingContactsCb != null) {
            String cb = pendingContactsCb; pendingContactsCb = null;
            if (has(Manifest.permission.READ_CONTACTS)) readContactsNow(cb);
            else {
                boolean never = !ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_CONTACTS);
                js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + ",{\"ok\":false,\"denied\":true,\"never\":" + never + "})");
            }
        } else if (code == RC_NOTIF) {
            js("window.__sawaNativePerm&&window.__sawaNativePerm(" + q(notifState()) + ")");
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == RC_FILE && fileCb != null) {
            fileCb.onReceiveValue(FileBridge.result(this, result, data));
            fileCb = null;
        }
        if (code == RC_SCREEN) {   // C141: موافقة «بدء التسجيل/البثّ» من النظام
            if (result == RESULT_OK && data != null) ScreenService.start(this, result, data);
            else screenEvent("denied");
        }
    }

    // ---------- C141: مشاركة الشاشة (الإطارات من ScreenService إلى الواجهة) ----------
    private static volatile boolean scrInflight = false;
    private static volatile long scrSentAt = 0;
    /** الواجهة لم تنتهِ من الإطار السابق ⇒ لا نرسل غيره (حدٌّ أقصى ٢ ث احتياطاً) */
    static boolean scrBusy() { return scrInflight && SystemClock.uptimeMillis() - scrSentAt < 2000; }
    static void screenFrame(final String b64, final int w, final int h) {
        final MainActivity a = inst.get();
        if (a == null || a.web == null) return;
        scrInflight = true; scrSentAt = SystemClock.uptimeMillis();
        MAIN.post(() -> {
            try { a.web.evaluateJavascript("window.__sawaScrFrame&&window.__sawaScrFrame('" + b64 + "'," + w + "," + h + ")", v -> scrInflight = false); }
            catch (Exception e) { scrInflight = false; }
        });
    }
    static void screenEvent(final String st) {
        final MainActivity a = inst.get();
        if (a == null || a.web == null) return;
        MAIN.post(() -> { try { a.web.evaluateJavascript("window.__sawaScr&&window.__sawaScr('" + st + "')", null); } catch (Exception e) { } });
    }
    private void screenAsk() {
        if (ScreenService.inst != null) { screenEvent("started"); return; }
        try {
            android.media.projection.MediaProjectionManager mpm = (android.media.projection.MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) { screenEvent("error"); return; }
            if (lock != null) lock.suppressNextStop = true;
            startActivityForResult(mpm.createScreenCaptureIntent(), RC_SCREEN);
        } catch (Exception e) { if (lock != null) lock.suppressNextStop = false; screenEvent("error"); }
    }

    private String notifState() {
        boolean enabled = NotificationManagerCompat.from(this).areNotificationsEnabled();
        if (enabled && (Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS))) return "granted";
        return Notifier.prefs(this).getBoolean("notif_asked", false) ? "denied" : "default";
    }

    private void fetchToken() {
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                if (!t.isSuccessful() || t.getResult() == null) return;
                String tok = t.getResult();
                Notifier.prefs(this).edit().putString("fcm", tok).apply();
                js("window.__sawaNativeToken&&window.__sawaNativeToken(" + q(tok) + ")");
            });
        } catch (Exception e) { /* Firebase غير مهيّأ */ }
    }

    private PowerManager.WakeLock proxLock;
    boolean proximitySupported() {
        try { PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE); return pm != null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK); }
        catch (Exception e) { return false; }
    }
    void setProximity(boolean on) {
        try {
            if (on) {
                if (proxLock == null && proximitySupported()) {
                    PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                    proxLock = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "sawa:proximity");
                    proxLock.setReferenceCounted(false);
                }
                if (proxLock != null && !proxLock.isHeld()) proxLock.acquire(4 * 60 * 60 * 1000L);
            } else if (proxLock != null && proxLock.isHeld()) {
                proxLock.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY);
            }
        } catch (Exception e) { }
    }


    // ===== C318: الرسائل الصوتيّة على سمّاعة الأذن عند تقريب الهاتف من الأذن (كواتساب) =====
    // مشغّل WebView يُخرج الرسائل الصوتيّة وسائطَ من المكبّر دائماً (لا يتبع «وضع الاتّصال»). لذلك: أثناء تشغيل رسالةٍ صوتيّة
    // نراقب حسّاس القرب؛ عند الأذن تسلّمنا الواجهة المقطع فنشغّله هنا بنوع «مكالمة» على سمّاعة الأذن من الموضع نفسه
    // (والشاشة تنطفئ)، وعند الإبعاد نعيد الموضع إلى الواجهة فتكمل على المكبّر. لا شيء من هذا أثناء مكالمة أو مع سمّاعة رأس.
    private android.hardware.SensorManager vnSm;
    private android.hardware.SensorEventListener vnL;
    private volatile boolean vnNear = false;
    private volatile int vnGen = 0;
    private final Object VN = new Object();
    private android.media.MediaPlayer vnMp;
    private boolean vnMode = false;
    boolean vnHasSensor() {
        try { android.hardware.SensorManager sm = (android.hardware.SensorManager) getSystemService(SENSOR_SERVICE); return sm != null && sm.getDefaultSensor(android.hardware.Sensor.TYPE_PROXIMITY) != null; }
        catch (Throwable t) { return false; }
    }
    void vnWatch(boolean on) {
        if (!on || inCallAudio || headsetConnected()) { vnStopAll(); return; }
        if (vnL != null) return;
        try {
            vnSm = (android.hardware.SensorManager) getSystemService(SENSOR_SERVICE);
            android.hardware.Sensor ps = vnSm == null ? null : vnSm.getDefaultSensor(android.hardware.Sensor.TYPE_PROXIMITY);
            if (ps == null) return;
            final float lim = Math.min(5f, ps.getMaximumRange());
            vnNear = false;
            vnL = new android.hardware.SensorEventListener() {
                @Override public void onSensorChanged(android.hardware.SensorEvent e) {
                    boolean n = e.values.length > 0 && e.values[0] < lim;
                    if (n == vnNear) return;
                    vnNear = n;
                    if (inCallAudio || (n && headsetConnected())) return;
                    js("window.__sawaVoiceNear&&window.__sawaVoiceNear(" + n + ")");
                }
                @Override public void onAccuracyChanged(android.hardware.Sensor s, int a) { }
            };
            vnSm.registerListener(vnL, ps, android.hardware.SensorManager.SENSOR_DELAY_NORMAL);
            setProximity(true);   // الشاشة تنطفئ عند الأذن
        } catch (Throwable t) { vnL = null; }
    }
    /** يُستدعى على الخيط الرئيس: تشغيل المقطع على سمّاعة الأذن من posMs. */
    private void vnPlay(int gen, String b64, int posMs, float rate) {
        vnRelease();
        if (gen != vnGen || !vnNear || inCallAudio || vnL == null) return;
        try {
            byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            java.io.File f = new java.io.File(getCacheDir(), "sawa-vn.bin");
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) { o.write(data); }
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            am.setMode(android.media.AudioManager.MODE_IN_COMMUNICATION); vnMode = true;
            if (Build.VERSION.SDK_INT >= 31) {
                for (android.media.AudioDeviceInfo d : am.getAvailableCommunicationDevices())
                    if (d.getType() == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE) { am.setCommunicationDevice(d); break; }
            } else { stopSco(am); am.setSpeakerphoneOn(false); }
            setVolumeControlStream(android.media.AudioManager.STREAM_VOICE_CALL);
            android.media.MediaPlayer mp = new android.media.MediaPlayer();
            mp.setAudioAttributes(new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build());
            mp.setDataSource(f.getPath());
            mp.setOnCompletionListener(x -> { vnRelease(); js("window.__sawaVoiceEnd&&window.__sawaVoiceEnd()"); });
            mp.setOnErrorListener((x, w, e) -> { vnRelease(); js("window.__sawaVoiceBack&&window.__sawaVoiceBack(-1)"); return true; });
            mp.prepare();
            if (posMs > 0) mp.seekTo(posMs);
            if (rate > 0 && Math.abs(rate - 1f) > 0.01f && Build.VERSION.SDK_INT >= 23) { try { mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(rate)); } catch (Throwable t) { } }
            synchronized (VN) { vnMp = mp; }
            mp.start();
        } catch (Throwable t) {
            vnRelease();
            js("window.__sawaVoiceBack&&window.__sawaVoiceBack(-1)");   // يكمل على المكبّر من حيث توقّف
        }
    }
    /** إيقاف المشغّل الأصليّ وإعادة وضع الصوت (يعمل من أيّ خيط بالنسبة للمشغّل؛ الوضع على الخيط الرئيس). */
    private void vnRelease() {
        android.media.MediaPlayer mp;
        synchronized (VN) { mp = vnMp; vnMp = null; }
        if (mp != null) { try { mp.stop(); } catch (Throwable t) { } try { mp.release(); } catch (Throwable t) { } }
        if (vnMode && !inCallAudio) {
            vnMode = false;
            try {
                android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
                if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice();
                setVolumeControlStream(android.media.AudioManager.USE_DEFAULT_STREAM_TYPE);
                am.setMode(android.media.AudioManager.MODE_NORMAL);
            } catch (Throwable t) { }
        }
    }
    private void vnStopAll() {
        vnGen++;
        vnRelease();
        if (vnL != null) {
            try { vnSm.unregisterListener(vnL); } catch (Throwable t) { }
            vnL = null; vnNear = false;
            if (!inCallAudio) setProximity(false);
        }
    }

    // C82: صفحات إعدادات الهاتف التي تقرّر هل يصل الإشعار والتطبيق مغلق
    private void openSetting(String kind) {
        String pkg = getPackageName();
        List<Intent> tries = new ArrayList<>();
        if ("battery".equals(kind)) {
            if (Build.VERSION.SDK_INT >= 23) tries.add(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg)));
            tries.add(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } else if ("fullscreen".equals(kind)) {
            if (Build.VERSION.SDK_INT >= 34) tries.add(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + pkg)));
        } else if ("notif".equals(kind)) {
            Intent i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
            i.putExtra("android.provider.extra.APP_PACKAGE", pkg);
            tries.add(i);
        } else if ("calls".equals(kind)) {
            if (Build.VERSION.SDK_INT >= 26) {
                Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
                i.putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH_CALLS);
                tries.add(i);
            }
        } else if ("launch".equals(kind)) {
            // «تشغيل التطبيقات» في Honor/Huawei، و«التشغيل التلقائيّ» في Xiaomi/Oppo/Vivo
            String[][] comps = {
                {"com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"},
            };
            for (String[] c : comps) { Intent i = new Intent(); i.setComponent(new ComponentName(c[0], c[1])); tries.add(i); }
        }
        tries.add(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
        for (Intent i : tries) {
            try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); lock.suppressNextStop = true; startActivity(i); return; } catch (Exception e) { lock.suppressNextStop = false; }
        }
    }

    // C88: قراءة جهات الهاتف في خيطٍ خلفيّ ثمّ إعادتها للواجهة (لا تُحفظ ولا تُرفع)
    private void readContactsNow(final String cb) {
        new Thread(() -> {
            String json;
            try {
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("list", PhoneContacts.read(MainActivity.this, 5000));
                json = o.toString();
            } catch (Exception e) { json = "{\"ok\":false}"; }
            js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + json + ")");
        }).start();
    }

    // C92: «وضع الاتّصال» أثناء المكالمة — يُفعّل مُلغي الصدى ومزيل الضوضاء في عتاد الهاتف ويوجّه الصوت كمكالمة هاتفيّة
    //      (كان الصوت يعمل في الوضع العاديّ كوسائط: صدى وتكرارٌ للكلام على المكبّر في هواتف كثيرة)، مع تركيز الصوت لإيقاف الموسيقى
    private android.media.AudioFocusRequest focusReq;
    private boolean inCallAudio = false;
    /* C229: مكالمةٌ أخرى (هاتف/واتساب/…) أخذت «تركيز الصوت» ⇒ مكالمة سوا «معلّقة»: لا نعيد «وضع الاتّصال» ولا المسار
       (كان routeTick يعيدهما كلّ ١٫٥ ث فيتنازع التطبيقان الصوت)، والواجهة تكتم الميكروفون. تعود حين تنتهي الأخرى. */
    private boolean audioHeld = false;
    /* C272: فقد «تركيز الصوت» وحده لا يعني مكالمةً أخرى — رنين واتساب (قبل الردّ) يأخذه، ومشغّل WebView في سوا نفسه قد يأخذه
       (فكان ميكروفون مضيف الغرفة يُكتم بعد ثوانٍ من بدئها، ومكالمة سوا «تنقطع» برنينٍ لم يُردّ عليه). الآن نعلّق فقط حين تثبت
       مكالمةٌ أخرى فعلاً: هاتفٌ جارٍ (MODE_IN_CALL) أو تطبيقٌ آخر أخذ الميكروفون (التقاطنا «مُسكَت» أو التقاطٌ إضافيّ).
       وكانت العودة تنتظر MODE_NORMAL الذي لا يأتي (وضعنا نحن IN_COMMUNICATION ما زال قائماً) فتبقى سوا معلّقةً إلى الأبد. */
    private boolean focusLost = false;
    /* C276: سجلّ أحداث الصوت (آخر ٦٠) — يظهر في «تشخيص الاتّصال» بالغرفة لتشخيص هاتفٍ بعينه (Honor) */
    private final java.util.ArrayDeque<String> aLog = new java.util.ArrayDeque<>();
    private long aT0 = 0;
    private String lastAEv = "";
    private void aEv(String e) {
        try {
            if (e.equals(lastAEv)) return;   // لا تكرار لحالةٍ ثابتة كلّ ١٫٥ ث
            lastAEv = e;
            long now = android.os.SystemClock.elapsedRealtime(); if (aT0 == 0) aT0 = now;
            synchronized (aLog) { aLog.addLast(((now - aT0) / 100) / 10.0 + "s " + e); while (aLog.size() > 60) aLog.removeFirst(); }
        } catch (Throwable t) { }
    }
    String audioLog() {
        StringBuilder b = new StringBuilder(Build.MANUFACTURER + " " + Build.MODEL + " · sdk " + Build.VERSION.SDK_INT + "\n");
        synchronized (aLog) { for (String x : aLog) b.append(x).append('\n'); }
        return b.toString();
    }
    private static String modeName(int m) { return m == 0 ? "NORMAL" : m == 1 ? "RINGTONE" : m == 2 ? "IN_CALL" : m == 3 ? "IN_COMM" : "m" + m; }
    private static String devName(int t) { return t == 1 ? "ear" : t == 2 ? "spk" : t == 3 || t == 4 ? "wired" : t == 7 ? "bt" : t == 22 ? "usb" : t == 26 ? "ble" : t == -1 ? "none" : "d" + t; }
    private int calmTicks = 0, recBase = -1;
    private final android.media.AudioManager.OnAudioFocusChangeListener focusL = ch -> {
        if (!inCallAudio) return;
        aEv("focus " + ch);   // C276
        // C275: فقد التركيز وحده لا يغيّر شيئاً — نتحقّق فوراً (والتحقّق يجري كلّ ١٫٥ ث أصلاً)
        if (ch == android.media.AudioManager.AUDIOFOCUS_LOSS || ch == android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) { focusLost = true; checkOtherCall(); }
        else if (ch == android.media.AudioManager.AUDIOFOCUS_GAIN) { focusLost = false; }
        // LOSS_TRANSIENT_CAN_DUCK (إشعارٌ قصير) ⇒ لا شيء
    };
    private void holdAudio(boolean on) {
        if (audioHeld == on || !inCallAudio) return;
        audioHeld = on;
        aEv("HOLD " + on + " " + holdWhy);   // C276
        js("window.__sawaAudioHold&&window.__sawaAudioHold(" + on + ")");
        if (!on) { MAIN.postDelayed(() -> { if (inCallAudio && !audioHeld) { applyRoute(); boostVolume(); } }, 300); }
    }
    /** C272: مكالمةٌ أخرى تملك الصوت الآن؟ (لا رنينها) */
    private boolean otherCallActive() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return false;
            int m = am.getMode();
            if (m == android.media.AudioManager.MODE_IN_CALL || m == 4 /* MODE_CALL_SCREENING */) { holdWhy = "mode=" + modeName(m); return true; }
            if (Build.VERSION.SDK_INT >= 29) {
                java.util.List<android.media.AudioRecordingConfiguration> l = am.getActiveRecordingConfigurations();
                for (android.media.AudioRecordingConfiguration c : l) if (c.isClientSilenced()) { holdWhy = "silenced rec=" + l.size(); return true; }   // أحدنا مُسكَت ⇒ تطبيقٌ آخر يتكلّم
                if (focusLost && recBase >= 0 && l.size() > recBase) { holdWhy = "newrec " + recBase + "->" + l.size(); return true; }   // تطبيقٌ آخر أخذ التركيز ومعه التقاطٌ جديد (C275: لا التقاطنا نحن حين نعيد فتح الميكروفون)
            }
        } catch (Throwable t) { }
        return false;
    }
    /** C272: تطبيقٌ آخر يرنّ (هاتف/واتساب) — لا نأخذ التركيز منه وإلّا أسكتنا رنينه */
    private boolean otherRinging() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am.getMode() == android.media.AudioManager.MODE_RINGTONE) return true;
            if (Build.VERSION.SDK_INT >= 26)
                for (android.media.AudioPlaybackConfiguration c : am.getActivePlaybackConfigurations())
                    if (c.getAudioAttributes().getUsage() == android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE) return true;
        } catch (Throwable t) { }
        return false;
    }
    private void recCount() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (Build.VERSION.SDK_INT >= 29 && am != null) recBase = am.getActiveRecordingConfigurations().size();
        } catch (Throwable t) { }
    }
    /** C275: يُستدعى كلّ ١٫٥ ث طوال المكالمة وعند فقد التركيز. لا نطلب «تركيز الصوت» من جديد أبداً — مشغّل الصوت في WebView
     *  (صوت المشاركين) يأخذه حين ينضمّ أحد، وطلبُنا له كان يُوقف مشغّلاته فيختفي الصوت في الغرفة بعد دخول ثالث. التركيز إرشاديّ لا نحتاجه. */
    private void checkOtherCall() {
        if (!inCallAudio) return;
        try {   // C276: حالةٌ مختصرة تُسجَّل حين تتغيّر فقط
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            String st = "mode=" + modeName(am.getMode());
            if (Build.VERSION.SDK_INT >= 31) { android.media.AudioDeviceInfo d = am.getCommunicationDevice(); st += " dev=" + devName(d == null ? -1 : d.getType()) + " spkFlag=" + am.isSpeakerphoneOn(); }   // C316
            else st += " spk=" + am.isSpeakerphoneOn();
            if (Build.VERSION.SDK_INT >= 29) { int n = 0, sil = 0; for (android.media.AudioRecordingConfiguration c : am.getActiveRecordingConfigurations()) { n++; if (c.isClientSilenced()) sil++; } st += " rec=" + n + (sil > 0 ? " silenced=" + sil : ""); }
            st += " want=" + (wantSpeaker ? "spk" : "ear") + (focusLost ? " focusLost" : "");
            aEv(st);
        } catch (Throwable t) { }
        if (otherCallActive()) { calmTicks = 0; holdAudio(true); return; }
        if (otherRinging()) { calmTicks = 0; ringing = true; return; }   // يرنّ فقط ⇒ مكالمة سوا تستمرّ ولا نأخذ الوضع/المسار منه
        ringing = false;
        if (audioHeld) { if (++calmTicks >= 2) { calmTicks = 0; holdAudio(false); } return; }   // ٣ ثوانٍ هادئة ⇒ نعود
        calmTicks = 0;
        recCount();
        if (routeWrong()) applyRoute();
    }
    private boolean ringing = false;
    private String holdWhy = "";
    /** C272: زرّ «استئناف» في الواجهة */
    private void resumeFromHold() {
        if (!inCallAudio) return;
        calmTicks = 0; ringing = false;
        if (audioHeld) holdAudio(false); else applyRoute();
    }
    private int prevCallVol = -1;
    private int spkFlagFixes = 0;   // C316
    private void callAudio(boolean on) {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null || on == inCallAudio) return;
            if (on && (vnL != null || vnMode)) vnStopAll();   // C318: مكالمةٌ تبدأ أثناء رسالةٍ صوتيّة
            inCallAudio = on;
            if (on) { aT0 = 0; lastAEv = ""; spkFlagFixes = 0; synchronized (aLog) { aLog.clear(); } }   // C316: spkFlagFixes   // C276: السجلّ يبدأ مع كلّ مكالمة/غرفة
            aEv("callAudio " + on);
            if (on) {
                am.setMode(android.media.AudioManager.MODE_IN_COMMUNICATION);
                // C96: أزرار الصوت تتحكّم بصوت المكالمة (لا الوسائط) + رفع صوت المكالمة إن كان أقلّ من النصف (يُعاد بعدها)
                setVolumeControlStream(android.media.AudioManager.STREAM_VOICE_CALL);
                try {
                    int mx = am.getStreamMaxVolume(android.media.AudioManager.STREAM_VOICE_CALL), v = am.getStreamVolume(android.media.AudioManager.STREAM_VOICE_CALL);
                    prevCallVol = -1;
                    if (mx > 0 && v < mx / 2) { prevCallVol = v; am.setStreamVolume(android.media.AudioManager.STREAM_VOICE_CALL, Math.max(1, mx * 4 / 5), 0); }
                } catch (Throwable t) { }
                if (Build.VERSION.SDK_INT >= 26) {
                    focusReq = new android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                            .setAudioAttributes(new android.media.AudioAttributes.Builder()
                                    .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                            .setOnAudioFocusChangeListener(focusL, MAIN).build();   // C229
                    am.requestAudioFocus(focusReq);
                }
                focusLost = false; ringing = false; calmTicks = 0; recBase = -1;   // C272
                routeWatch(true);   // C196
            } else {
                audioHeld = false; focusLost = false; recBase = -1;   // C229 · C272
                routeWatch(false); callTone("");   // C196
                watchDevices(false); wantSpeaker = false;
                if (Build.VERSION.SDK_INT >= 31) { try { am.clearCommunicationDevice(); } catch (Throwable t) { } }
                else { stopSco(am); am.setSpeakerphoneOn(false); }
                try { if (prevCallVol >= 0) am.setStreamVolume(android.media.AudioManager.STREAM_VOICE_CALL, prevCallVol, 0); } catch (Throwable t) { }
                prevCallVol = -1;
                setVolumeControlStream(android.media.AudioManager.USE_DEFAULT_STREAM_TYPE);
                am.setMode(android.media.AudioManager.MODE_NORMAL);
                if (focusReq != null && Build.VERSION.SDK_INT >= 26) am.abandonAudioFocusRequest(focusReq);
                focusReq = null;
            }
        } catch (Throwable t) { }
    }
    // C150: سمّاعات الرأس (سلكيّة/USB/بلوتوث) — كان «سمّاعة الأذن» يُفرض صراحةً (setCommunicationDevice) فيتجاوز السمّاعة الموصولة
    //       فلا يُسمع شيءٌ فيها. الآن: المكبّر عند طلبه · وإلّا سمّاعة الرأس إن وُجدت · وإلّا سمّاعة الأذن. ويُعاد عند توصيلها أو فصلها أثناء المكالمة.
    private boolean wantSpeaker = false;
    private android.media.AudioDeviceCallback devCb;
    private static final int[] HEADSETS = {
            android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET, android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            22 /* TYPE_USB_HEADSET */, android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            26 /* TYPE_BLE_HEADSET */, 23 /* TYPE_HEARING_AID */ };
    private static boolean isHeadset(int t) { for (int h : HEADSETS) if (h == t) return true; return false; }
    private void setSpeaker(boolean on) { setSpeaker(on, false); }
    /** C230: auto = اختيار التطبيق (بداية مكالمة فيديو) لا المستخدم ⇒ لا يغلب سمّاعةً موصولة. زرّ المستخدم يحوّل إلى المكبّر دائماً. */
    private void setSpeaker(boolean on, boolean auto) {
        if (on && auto && headsetConnected()) on = false;
        wantSpeaker = on;
        if (!inCallAudio) callAudio(true);   // C196: التوجيه يبدأ مع الاتّصال/الرنين لا عند الردّ فقط — وبلا «وضع الاتّصال» يخرج الصوت وسائطَ من المكبّر
        NativeRtc.speaker(on);   // C113
        applyRoute();
        watchDevices(true);
        MAIN.postDelayed(this::boostVolume, 350);   // C196
        MAIN.postDelayed(this::tellUi, 500);   // C230
    }
    /** C230: سمّاعة رأس صالحة للمكالمات موصولة (سلكيّة · USB · بلوتوث مكالمات · BLE · سمّاعة طبّيّة) — بلا مكبّرات البلوتوث (A2DP) التي لا تحمل صوت المكالمة */
    private boolean headsetConnected() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) if (isHeadset(d.getType())) return true;
        } catch (Throwable t) { }
        return false;
    }
    /** C230: ما يخرج منه الصوت فعلاً (headset · spk · ear) ⇒ الواجهة تطابق زرّ الصوت. كان الزرّ يقول «السمّاعة» والصوت في سمّاعة الرأس. */
    private void tellUi() {
        if (!inCallAudio) return;
        // المسار المفروض (routeTick يعيده إن غيّره WebView لحظةً) لا لقطةٌ عابرة قد تكون خاطئة
        boolean hs = headsetConnected();
        String kind = wantSpeaker ? "spk" : hs ? "headset" : "ear";
        js("window.__sawaAudioOut&&window.__sawaAudioOut(" + q(kind) + "," + hs + ")");
    }
    /* C196: (١) WebView (Chromium) يختار المكبّر افتراضيّاً كلّما فتح الميكروفون أو بدأ صوت الطرف الآخر، فيضيع اختيار
       «سمّاعة الأذن» ولا يعمل زرّ التحويل ⇒ نراقب المسار الفعليّ طوال المكالمة ونعيده إلى ما اختاره المستخدم.
       (٢) صوت المكالمة في أندرويد مستقلّ لكلّ جهاز (المكبّر غير سمّاعة الأذن) — كنّا نرفع صوت الجهاز الأوّل فقط، فيبقى المكبّر خافتاً. */
    private final Runnable routeTick = new Runnable() {
        @Override public void run() {
            if (!inCallAudio) return;
            // C229/C272: التركيز مفقود أو معلّقون ⇒ لا ننازع على الوضع/المسار، بل نتحقّق هل انتهت الأخرى
            try { checkOtherCall(); } catch (Throwable t) { }   // C275
            MAIN.postDelayed(this, 1500);
        }
    };
    private Object commCb;
    private void routeWatch(boolean on) {
        MAIN.removeCallbacks(routeTick);
        if (on) MAIN.postDelayed(routeTick, 1500);
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null && Build.VERSION.SDK_INT >= 31) {
                if (on && commCb == null) {
                    android.media.AudioManager.OnCommunicationDeviceChangedListener l = d -> {
                        if (!inCallAudio || audioHeld || ringing) return;   // C229 · C275
                        MAIN.postDelayed(() -> {
                            long now = android.os.SystemClock.elapsedRealtime();
                            if (inCallAudio && !audioHeld && !ringing && now - lastFix > 1000 && routeWrong()) { lastFix = now; applyRoute(); }
                        }, 250);
                    };
                    am.addOnCommunicationDeviceChangedListener(getMainExecutor(), l);
                    commCb = l;
                } else if (!on && commCb != null) {
                    am.removeOnCommunicationDeviceChangedListener((android.media.AudioManager.OnCommunicationDeviceChangedListener) commCb);
                    commCb = null;
                }
            }
        } catch (Throwable t) { }
    }
    private long lastFix = 0;
    @SuppressWarnings("deprecation")
    private boolean routeWrong() {
        android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
        if (am == null) return false;
        if (am.getMode() != android.media.AudioManager.MODE_IN_COMMUNICATION) return true;
        if (Build.VERSION.SDK_INT >= 31) {
            android.media.AudioDeviceInfo d = am.getCommunicationDevice();
            int t = d == null ? -1 : d.getType();
            if (isHeadset(t)) return wantSpeaker;   // سمّاعة رأس موصولة: صحيحٌ ما لم يُطلب المكبّر
            if (!wantSpeaker) {   // جهازٌ بلا سمّاعة أذن (لوحيّ) ⇒ لا نحاول بلا نهاية
                boolean hasEar = false;
                for (android.media.AudioDeviceInfo x : am.getAvailableCommunicationDevices()) if (x.getType() == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE) hasEar = true;
                if (!hasEar) return false;
            }
            if (!wantSpeaker && !isHeadset(t) && spkFlagFixes < 6) { try { if (am.isSpeakerphoneOn()) return true; } catch (Throwable x) { } }   // C316: علم المكبّر القديم مرفوع (حتّى ٦ محاولات لكلّ مكالمة)
            return wantSpeaker ? t != android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER : t == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER || t == -1;
        }
        boolean headset = false;
        for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) if (isHeadset(d.getType())) headset = true;
        if (headset && !wantSpeaker) return false;
        return am.isSpeakerphoneOn() != wantSpeaker;
    }
    /** C196: صوت المكالمة على الجهاز الحاليّ (مكبّر أو سمّاعة) لا يقلّ عن ٨٥٪ إن كان أقلّ من ٧٠٪ — أزرار الصوت تبقى تتحكّم به */
    private void boostVolume() {
        try {
            if (!inCallAudio) return;
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            int mx = am.getStreamMaxVolume(android.media.AudioManager.STREAM_VOICE_CALL), v = am.getStreamVolume(android.media.AudioManager.STREAM_VOICE_CALL);
            if (mx > 0 && v < mx * 7 / 10) am.setStreamVolume(android.media.AudioManager.STREAM_VOICE_CALL, Math.max(1, (mx * 85 + 99) / 100), 0);
        } catch (Throwable t) { }
    }
    /** C196: نغمة «يرنّ» عند المتّصل من النظام على مسار المكالمة (سمّاعة الأذن/المكبّر حسب الاختيار) — "" يوقفها */
    private android.media.ToneGenerator toneGen;
    void callTone(String kind) {
        try { if (toneGen != null) { toneGen.stopTone(); toneGen.release(); } } catch (Throwable t) { }
        toneGen = null;
        if (kind == null || kind.isEmpty()) return;
        try {
            if (!inCallAudio) { callAudio(true); applyRoute(); }
            toneGen = new android.media.ToneGenerator(android.media.AudioManager.STREAM_VOICE_CALL, 70);
            toneGen.startTone(android.media.ToneGenerator.TONE_SUP_RINGTONE);
        } catch (Throwable t) { toneGen = null; }
    }
    @SuppressWarnings("deprecation")
    private void applyRoute() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null || audioHeld || ringing) return;
            aEv("applyRoute want=" + (wantSpeaker ? "spk" : "ear") + " mode=" + modeName(am.getMode()));   // C276   // C229: مكالمةٌ أخرى تملك الصوت الآن · C272: أو ترنّ (لا نأخذ «الوضع» منها)
            // C177: بعض الهواتف (ومعها WebView حين يعيد فتح الميكروفون) تُرجع الوضع إلى «عاديّ» فيخرج الصوت وسائطَ من المكبّر
            //       مهما اخترنا سمّاعة الأذن — نعيد «وضع الاتّصال» قبل كلّ توجيه
            if (inCallAudio && am.getMode() != android.media.AudioManager.MODE_IN_COMMUNICATION) am.setMode(android.media.AudioManager.MODE_IN_COMMUNICATION);
            if (Build.VERSION.SDK_INT >= 31) {
                java.util.List<android.media.AudioDeviceInfo> devs = am.getAvailableCommunicationDevices();
                android.media.AudioDeviceInfo pick = null, ear = null, spk = null;
                for (android.media.AudioDeviceInfo d : devs) {
                    int t = d.getType();
                    if (t == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) spk = d;
                    else if (t == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE) ear = d;
                    else if (isHeadset(t) && (pick == null || t != android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO)) pick = d;   // السلكيّة أوّلاً ثمّ البلوتوث
                }
                android.media.AudioDeviceInfo want = wantSpeaker ? spk : (pick != null ? pick : ear);
                // C316: شاومي (MIUI/HyperOS) وتيكنو (HiOS): WebView يرفع علم «المكبّر» القديم حين يفتح الميكروفون، فإن بقي مرفوعاً
                //       مع سمّاعة الأذن خرج الصوت من السمّاعة والمكبّر معاً («من كلّ الجهات») ⇒ نُنزله أوّلاً ثمّ نختار الجهاز
                if (!wantSpeaker && spkFlagFixes < 6) { try { if (am.isSpeakerphoneOn()) { am.setSpeakerphoneOn(false); spkFlagFixes++; aEv("spkFlag off #" + spkFlagFixes); } } catch (Throwable t) { } }
                if (want != null) am.setCommunicationDevice(want); else am.clearCommunicationDevice();
            } else {
                boolean wired = false, bt = false;
                for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
                    int t = d.getType();
                    if (t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO) bt = true;
                    else if (isHeadset(t)) wired = true;
                }
                if (wantSpeaker) { stopSco(am); am.setSpeakerphoneOn(true); }
                else if (bt && !wired) { am.setSpeakerphoneOn(false); if (!am.isBluetoothScoOn()) { am.startBluetoothSco(); am.setBluetoothScoOn(true); } }
                else { stopSco(am); am.setSpeakerphoneOn(false); }   // السلكيّة يوجّهها النظام تلقائيّاً
            }
        } catch (Throwable t) { }
    }
    @SuppressWarnings("deprecation")
    private void stopSco(android.media.AudioManager am) { try { if (am.isBluetoothScoOn()) { am.setBluetoothScoOn(false); am.stopBluetoothSco(); } } catch (Throwable t) { } }
    private void watchDevices(boolean on) {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return;
            if (on && devCb == null) {
                devCb = new android.media.AudioDeviceCallback() {
                    // C230: سمّاعةٌ وُصلت أثناء المكالمة ⇒ الصوت ينتقل إليها ولو كان على المكبّر (كتطبيق الهاتف)، والزرّ يتبع
                    @Override public void onAudioDevicesAdded(android.media.AudioDeviceInfo[] a) {
                        if (!inCallAudio) return;
                        boolean hs = false; for (android.media.AudioDeviceInfo d : a) if (isHeadset(d.getType())) hs = true;
                        if (hs && wantSpeaker) { wantSpeaker = false; NativeRtc.speaker(false); }
                        MAIN.postDelayed(() -> { applyRoute(); MAIN.postDelayed(MainActivity.this::tellUi, 400); }, 400);
                    }
                    @Override public void onAudioDevicesRemoved(android.media.AudioDeviceInfo[] a) {
                        if (inCallAudio) MAIN.postDelayed(() -> { applyRoute(); MAIN.postDelayed(MainActivity.this::tellUi, 400); }, 400);
                    }
                };
                am.registerAudioDeviceCallback(devCb, MAIN);
            } else if (!on && devCb != null) { am.unregisterAudioDeviceCallback(devCb); devCb = null; }
        } catch (Throwable t) { }
    }
    /** للواجهة: «headset» إن كانت سمّاعة رأس موصولة (يظهر 🎧 بدل زرّ المكبّر/الأذن) */
    /** C177: المسار الفعليّ للتشخيص — الجهاز الذي يخرج منه صوت المكالمة ووضع الصوت (٣ = وضع الاتّصال) */
    @SuppressWarnings("deprecation")
    String audioRoute() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            String dev;
            if (Build.VERSION.SDK_INT >= 31) {
                android.media.AudioDeviceInfo d = am.getCommunicationDevice();
                int t = d == null ? -1 : d.getType();
                dev = t == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE ? "earpiece" : t == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER ? "speaker" : isHeadset(t) ? "headset" : ("type " + t);
                if (am.isSpeakerphoneOn()) dev += " +spkFlag";   // C316: المكبّر القديم مرفوعٌ مع الجهاز المختار (شاومي/تيكنو)
            } else dev = am.isSpeakerphoneOn() ? "speaker" : am.isBluetoothScoOn() ? "bluetooth" : "earpiece";
            return dev + " · mode " + am.getMode();
        } catch (Throwable t) { return "?"; }
    }
    String audioOut() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (headsetConnected()) return "headset";   // C230: بلا A2DP (مكبّر بلوتوث للموسيقى لا يحمل صوت المكالمة)
        } catch (Throwable t) { }
        return wantSpeaker ? "speaker" : "earpiece";
    }

    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { /* لا تطبيق يفتحه */ }
    }

    // ---------- الدخول بـGoogle أصليّاً (Google تمنع الدخول من داخل WebView) ----------
    private void googleSignIn(final String cb) {
        try {
            GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(BuildConfig.WEB_CLIENT_ID).build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            CredentialManager cm = CredentialManager.create(this);
            cm.getCredentialAsync(this, req, new CancellationSignal(), ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override
                        public void onResult(GetCredentialResponse r) {
                            Credential c = r.getCredential();
                            String token = null;
                            if (c instanceof CustomCredential && "com.google.android.libraries.identity.googleid.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL".equals(c.getType())) {
                                token = c.getData().getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_ID_TOKEN");
                            }
                            reply(cb, token != null, token, token != null ? "" : "no-token");
                        }

                        @Override
                        public void onError(@NonNull GetCredentialException e) {
                            reply(cb, false, null, e.getClass().getSimpleName() + ": " + e.getMessage());
                        }
                    });
        } catch (Exception e) {
            reply(cb, false, null, String.valueOf(e));
        }
    }

    private void reply(String cb, boolean ok, String token, String err) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (token != null) o.put("idToken", token);
            if (err != null && !err.isEmpty()) o.put("error", err);
            js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + o.toString() + ")");
        } catch (Exception e) { }
    }

    /** الجسر الذي تراه الواجهة: window.SawaNativeBridge */
    class Bridge {
        /** C130b: الواجهة تُظهر «الألبومات» في صورة الحساب فقط حين يدعمها هذا البناء. */
        @JavascriptInterface public boolean albumsOk() { return true; }
        @JavascriptInterface public boolean screenOk() { return true; }
        @JavascriptInterface public void setPip(final boolean on) { MAIN.post(() -> setPipWanted(on)); }   // C142   // C141: مشاركة الشاشة في الغرف
        @JavascriptInterface public void screenStart() { MAIN.post(MainActivity.this::screenAsk); }
        @JavascriptInterface public void screenStop() { MAIN.post(() -> ScreenService.stop(MainActivity.this)); }
        @JavascriptInterface public String platform() { return "android/" + BuildConfig.VERSION_NAME; }
        @JavascriptInterface public String fcmToken() { return Notifier.prefs(MainActivity.this).getString("fcm", ""); }
        @JavascriptInterface public String notifPermission() { return notifState(); }

        @JavascriptInterface public void requestNotifPermission() {
            MAIN.post(() -> {
                boolean askedBefore = Notifier.prefs(MainActivity.this).getBoolean("notif_asked", false);
                Notifier.prefs(MainActivity.this).edit().putBoolean("notif_asked", true).apply();
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS) && askedBefore
                        && !ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS)) {
                    // C348: رُفض نهائيّاً — النظام لن يُظهر نافذته ثانية ⇒ نفتح صفحة إشعارات سوا مباشرة (الواجهة تفحص عند العودة)
                    openSetting("notif");
                } else if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIF);
                } else if (!NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled()) {
                    // محظورة من الإعدادات ⇒ نفتح صفحة إشعارات التطبيق
                    Intent i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
                    i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                    try { startActivity(i); } catch (Exception e) { }
                } else {
                    js("window.__sawaNativePerm&&window.__sawaNativePerm('granted')");
                }
                fetchToken();
            });
        }

        @JavascriptInterface public void googleSignIn(final String cb) { MAIN.post(() -> MainActivity.this.googleSignIn(cb)); }

        @JavascriptInterface public void setInCall(final boolean on, final String title) {
            MAIN.post(() -> {
                // C82: الشاشة تبقى مضاءة طوال المكالمة (كانت تُطفأ بمهلة الشاشة بعد ثوانٍ فتبدو سوداء)
                try { if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); } catch (Exception e) { }
                if (on) CallService.start(MainActivity.this, title);
                else { CallService.stop(MainActivity.this); setProximity(false); if (lock != null) lock.callEnded(); overLock(false); setPipWanted(false); }
                callAudio(on);   // C92
            });
        }

        // C291: مكالمة الفيديو ⇒ خدمة المكالمة بنوع «الكاميرا» (لا تنقطع الكاميرا حين تخرج من سوا)
        @JavascriptInterface public void callVideo(final boolean on) { MAIN.post(() -> CallService.setVideo(MainActivity.this, on)); }

        // C92: مكبّر الصوت ↔ سمّاعة الأذن من زرّ المكالمة (مع وضع الاتّصال)
        @JavascriptInterface public void setSpeaker(final boolean on) { MAIN.post(() -> MainActivity.this.setSpeaker(on)); }
        @JavascriptInterface public void setSpeakerAuto(final boolean on) { MAIN.post(() -> MainActivity.this.setSpeaker(on, true)); }   // C230
        @JavascriptInterface public String audioLog() { return MainActivity.this.audioLog(); }   // C276
        @JavascriptInterface public void audioResume() { MAIN.post(MainActivity.this::resumeFromHold); }   // C272
        @JavascriptInterface public String audioOut() { return MainActivity.this.audioOut(); }   // C150
        @JavascriptInterface public String audioRoute() { return MainActivity.this.audioRoute(); }   // C177
        @JavascriptInterface public void callTone(final String kind) { MAIN.post(() -> MainActivity.this.callTone(kind)); }   // C196

        // C95: محرّك المكالمات الصوتيّة الأصليّ (NativeRtc) — سقفٌ لمخزن الصوت بدل تضخّمه في WebView
        @JavascriptInterface public int rtcVersion() { return 2; }
        @JavascriptInterface public void rtcAudioBr(String id, int bps) { NativeRtc.audioBitrate(id, bps); }   // C110
        @JavascriptInterface public boolean rtcMicOk() { return has(Manifest.permission.RECORD_AUDIO); }
        @JavascriptInterface public void rtcNew(String id, String iceJson, String cb) { NativeRtc.create(MainActivity.this, id, iceJson, cb); }
        @JavascriptInterface public void rtcPre(String id, String iceJson) { NativeRtc.prewarm(MainActivity.this, id, iceJson); }   // C218: تجهيزٌ أثناء الرنين
        @JavascriptInterface public void rtcAddAudio(String id) { NativeRtc.addAudio(id); }
        @JavascriptInterface public void rtcCreate(String id, boolean offer, boolean iceRestart, String cb) { NativeRtc.createSdp(id, offer, iceRestart, cb); }
        @JavascriptInterface public void rtcSet(String id, boolean local, String type, String sdp, String cb) { NativeRtc.setSdp(id, local, type, sdp, cb); }
        @JavascriptInterface public void rtcIce(String id, String json) { NativeRtc.addIce(id, json); }
        @JavascriptInterface public void rtcStats(String id, String cb) { NativeRtc.stats(id, cb); }
        @JavascriptInterface public void rtcMute(boolean m) { NativeRtc.setMuted(m); }
        @JavascriptInterface public void rtcClose(String id) { NativeRtc.close(id); }

        @JavascriptInterface public void openExternal(final String url) { MAIN.post(() -> MainActivity.this.openExternal(url)); }

        // C227: إزالة إشعار المحادثة عند فتحها داخل التطبيق (المعرّف نفسه في Notifier.message) — كان يبقى في الشريط
        @JavascriptInterface public void clearChatNotif(final String cid) {
            if (cid == null || cid.isEmpty()) return;
            try { androidx.core.app.NotificationManagerCompat.from(MainActivity.this).cancel(Notifier.chatNotifId(cid)); } catch (Exception e) { }
            Notifier.clearChatCount(MainActivity.this, cid);   // C314
        }
        // C314: عدد غير المقروء على أيقونة التطبيق (WebView لا يدعم navigator.setAppBadge)
        @JavascriptInterface public void setBadge(final int n) { Notifier.setAppBadge(MainActivity.this, n); }
        // C227: المحادثة المفتوحة الآن — لا يُعرض إشعارٌ لرسالةٍ فيها والتطبيق أمامك
        @JavascriptInterface public void setOpenChat(final String cid) { openChat = cid == null ? "" : cid; }
        @JavascriptInterface public void callDone(final String callId) { Notifier.stopRinging(MainActivity.this, callId, true); }

        // C82: ما يمنع وصول المكالمات والتطبيق مغلق — للعرض في «فحص الإشعارات» مع أزرار الإصلاح
        @JavascriptInterface public String bgStatus() {
            try {
                JSONObject o = new JSONObject();
                o.put("notif", NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled());
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                    android.app.NotificationChannel ch = nm.getNotificationChannel(Notifier.CH_CALLS);
                    o.put("callsChannel", ch == null ? -1 : ch.getImportance());
                }
                if (Build.VERSION.SDK_INT >= 34 && nm != null) o.put("fullScreen", nm.canUseFullScreenIntent());
                else o.put("fullScreen", true);
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                o.put("battery", Build.VERSION.SDK_INT < 23 || (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())));
                o.put("maker", String.valueOf(Build.MANUFACTURER).toLowerCase());
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("fcm", Notifier.prefs(MainActivity.this).getString("fcm", "").length() > 0);
                android.content.SharedPreferences pp = Notifier.prefs(MainActivity.this);
                if (pp.getLong("lp_ts", 0) > 0) {   // C84: آخر إشعارٍ وصل فعلاً
                    JSONObject lp = new JSONObject();
                    lp.put("ts", pp.getLong("lp_ts", 0)); lp.put("t", pp.getString("lp_t", "")); lp.put("fg", pp.getBoolean("lp_fg", false));
                    lp.put("shown", pp.getBoolean("lp_shown", true)); lp.put("pri", pp.getInt("lp_pri", 0)); lp.put("n", pp.getInt("lp_n", 0));
                    o.put("lastPush", lp);
                }
                if (pp.getLong("lr_ts", 0) > 0) {   // C85: آخر مكالمةٍ واردة وكيف عُرضت (أو لماذا فشل عرضها)
                    JSONObject lr = new JSONObject();
                    lr.put("ts", pp.getLong("lr_ts", 0)); lr.put("mode", pp.getString("lr_mode", "")); lr.put("err", pp.getString("lr_err", "")); lr.put("fsi", pp.getBoolean("lr_fsi", true));
                    o.put("lastRing", lr);
                }
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        // C82: حسّاس القرب الحقيقيّ في المكالمة الصوتيّة على السمّاعة — الشاشة تنطفئ عند الأذن وتعود حين تبعد الهاتف
        //      (بدل «وضع الأذن» في الويب: شاشةٌ سوداء بعد ٥ ثوانٍ لا تعود إلّا بالضغط المطوّل)
        @JavascriptInterface public boolean setProximity(final boolean on) {
            MAIN.post(() -> MainActivity.this.setProximity(on));
            return proximitySupported();
        }

        // C318: الرسائل الصوتيّة على سمّاعة الأذن — vnWatch أثناء التشغيل · vnPlay عند الأذن · vnStop عند الإبعاد (يعيد الموضع بالملّي ثانية أو -1)
        @JavascriptInterface public boolean vnWatch(final boolean on) {
            if (on) vnGen++;
            MAIN.post(() -> MainActivity.this.vnWatch(on));
            return on && vnHasSensor();
        }
        @JavascriptInterface public boolean vnPlay(final String b64, final int posMs, final double rate) {
            if (b64 == null || b64.isEmpty()) return false;
            final int g = vnGen;
            MAIN.post(() -> MainActivity.this.vnPlay(g, b64, posMs, (float) rate));
            return true;
        }
        @JavascriptInterface public int vnStop() {
            vnGen++;
            int p = -1;
            synchronized (VN) { if (vnMp != null) { try { p = vnMp.getCurrentPosition(); } catch (Throwable t) { } } }
            MAIN.post(MainActivity.this::vnRelease);
            return p;
        }

        // C84: قائمة المشاركة الأصليّة (واتساب، تيليجرام…) — WebView لا يعرف navigator.share
        @JavascriptInterface public void share(final String title, final String text) {
            MAIN.post(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    if (title != null && !title.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, title);
                    startActivity(Intent.createChooser(i, title == null || title.isEmpty() ? "مشاركة" : title));
                } catch (Exception e) { }
            });
        }

        // C89: ملفٌّ من المحادثة ⇒ فتح/حفظ/مشاركة (قطع base64) · وما شورِك إلى سوا ⇒ تسحبه الواجهة قطعاً
        @JavascriptInterface public String fileBegin(String name, String mime) { return FileBridge.begin(MainActivity.this, name, mime); }
        @JavascriptInterface public boolean fileChunk(String id, String b64) { return FileBridge.chunk(id, b64); }
        @JavascriptInterface public void fileEnd(final String id, final String action, final String cb) {
            MAIN.post(() -> {
                if (!"save".equals(action)) lock.suppressNextStop = true;
                String r = FileBridge.end(MainActivity.this, id, action);
                js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + r + ")");
            });
        }
        @JavascriptInterface public String shareInTake() { return FileBridge.take(); }
        @JavascriptInterface public String shareInRead(String id, int off, int len) { return FileBridge.read(id, off, len); }
        @JavascriptInterface public void shareInDone(String id) { FileBridge.done(id); }

        // C88: جهات الهاتف (بإذن READ_CONTACTS) + رسالة نصّيّة جاهزة
        @JavascriptInterface public void readContacts(final String cb) {
            MAIN.post(() -> {
                if (has(Manifest.permission.READ_CONTACTS)) { readContactsNow(cb); return; }
                pendingContactsCb = cb;
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_CONTACTS}, RC_CONTACTS);
            });
        }

        @JavascriptInterface public void sms(final String phone, final String body) {
            MAIN.post(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(phone == null ? "" : phone)));
                    i.putExtra("sms_body", body == null ? "" : body);
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, body == null ? "" : body);
                        startActivity(Intent.createChooser(i, "إرسال"));
                    } catch (Exception e2) { }
                }
            });
        }

        // C350: حفظ رقمٍ من سوا في جهات الهاتف — شاشة «جهة اتّصال جديدة» من النظام (لا تحتاج إذن جهات الاتّصال)
        @JavascriptInterface public void addContact(final String name, final String phone, final String note) {
            MAIN.post(() -> {
                try {
                    Intent i = new Intent(android.provider.ContactsContract.Intents.Insert.ACTION);
                    i.setType(android.provider.ContactsContract.RawContacts.CONTENT_TYPE);
                    if (name != null && !name.isEmpty()) i.putExtra(android.provider.ContactsContract.Intents.Insert.NAME, name);
                    i.putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, phone == null ? "" : phone);
                    i.putExtra(android.provider.ContactsContract.Intents.Insert.PHONE_TYPE, android.provider.ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
                    if (note != null && !note.isEmpty()) i.putExtra(android.provider.ContactsContract.Intents.Insert.NOTES, note);
                    i.putExtra("finishActivityOnSaveCompleted", true);   // يعود إلى سوا بعد الحفظ
                    startActivity(i);
                } catch (Exception e) {
                    try { android.widget.Toast.makeText(MainActivity.this, "لا يوجد تطبيق جهات اتّصال على هذا الهاتف", android.widget.Toast.LENGTH_LONG).show(); } catch (Exception e2) { }
                }
            });
        }

        @JavascriptInterface public void openSetting(final String kind) {
            MAIN.post(() -> MainActivity.this.openSetting(kind));
        }

        // C73: قفل التطبيق
        @JavascriptInterface public String appLockState() { return lock != null ? lock.stateJson(null) : "{}"; }

        @JavascriptInterface public void setAppLock(final boolean on, final double afterMs, final String cb) {
            MAIN.post(() -> lock.set(on, (long) afterMs, (ok, err) -> {
                try {
                    JSONObject o = new JSONObject(lock.stateJson(null));
                    o.put("ok", ok);
                    if (err != null) o.put("error", err);
                    js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + o.toString() + ")");
                } catch (Exception e) { }
            }));
        }

        // C285: تحقّق صاحب الهاتف (البصمة أو قفل الشاشة) لعمليّاتٍ حسّاسة في الواجهة — مثل «نسيت رمز المحفظة»
        @JavascriptInterface public boolean ownerAuthOk() { return lock != null && lock.available(); }

        @JavascriptInterface public void verifyOwner(final String title, final String cb) {
            MAIN.post(() -> {
                final AppLock.Done reply = (ok, err) -> {
                    try {
                        JSONObject o = new JSONObject();
                        o.put("ok", ok);
                        if (err != null) o.put("error", err);
                        js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + o.toString() + ")");
                    } catch (Exception e) { }
                };
                // لا نمرّ بـ authenticate() بلا قفل شاشة: هناك يُلغى قفل التطبيق كي لا يُحبس صاحبه — لا شأن لنا به هنا
                if (lock == null || !lock.available()) { reply.done(false, "no-screen-lock"); return; }
                lock.authenticate(title == null || title.isEmpty() ? "تأكيد الهويّة" : title, reply);
            });
        }

        // C73: ماسح QR الأصليّ
        @JavascriptInterface public void scanQr(final String cb) {
            MAIN.post(() -> {
                lock.suppressNextStop = true;
                QrScan.start(MainActivity.this, (value, cancelled, err) -> {
                    lock.suppressNextStop = false;
                    try {
                        JSONObject o = new JSONObject();
                        o.put("ok", value != null);
                        if (value != null) o.put("value", value);
                        if (cancelled) o.put("cancelled", true);
                        if (err != null) o.put("error", err);
                        js("window.__sawaNativeCb&&window.__sawaNativeCb(" + q(cb) + "," + o.toString() + ")");
                    } catch (Exception e) { }
                });
            });
        }
    }
}
