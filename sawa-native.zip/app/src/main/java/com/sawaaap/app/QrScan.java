package com.sawaaap.app;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

/**
 * C73: ماسح QR أصليّ من خدمات Google Play — لا يحتاج إذن الكاميرا، ويقرأ الرمز بسرعة حتّى في الإضاءة الضعيفة.
 * إن لم تتوفّر خدمات Google يعود الخطأ فتستعمل الواجهة ماسحها (الكاميرا داخل الصفحة).
 */
final class QrScan {
    interface Done { void done(String value, boolean cancelled, String err); }

    static void start(MainActivity a, Done cb) {
        try {
            GmsBarcodeScannerOptions opt = new GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build();
            GmsBarcodeScanner sc = GmsBarcodeScanning.getClient(a, opt);
            sc.startScan()
                    .addOnSuccessListener(b -> cb.done(b != null ? b.getRawValue() : null, false, null))
                    .addOnCanceledListener(() -> cb.done(null, true, null))
                    .addOnFailureListener(e -> cb.done(null, false, String.valueOf(e)));
        } catch (Throwable t) {
            cb.done(null, false, String.valueOf(t));
        }
    }
}
