# سوا — تطبيق أندرويد الأصليّ (C72)

يعرض www.sawaaap.com داخل WebView، مع أجزاء أصليّة:

- **إشعارات FCM أصليّة** (`SawaMessagingService`) بأولويّة عالية — تصل والتطبيق مغلق.
- **شاشة مكالمة واردة كاملة** فوق قفل الهاتف (`IncomingCallActivity` + إشعار `CallStyle`) بنغمة رنين الهاتف تتكرّر حتى الردّ أو الرفض.
- **خدمة «مكالمة جارية»** (`CallService`، خدمة أماميّة) تُبقي المكالمة والغرفة حيّتين في الخلفيّة، مع إشعارٍ بزرَّي «العودة» و«إنهاء».
- **الدخول بـGoogle أصليّاً** (Credential Manager)، لأنّ Google تمنع الدخول من داخل WebView.
- **C73 قفل التطبيق** (`AppLock`): بالبصمة أو قفل شاشة الهاتف، يُفعَّل من «الخصوصية والأمان»؛ لا يُقفل أثناء مكالمة.
- **C73 ماسح QR أصليّ** (`QrScan`، خدمات Google): لا يحتاج إذن الكاميرا؛ وإن لم يتوفّر تعود الواجهة إلى ماسحها.
- **C73 أيقونة متكيّفة** (`mipmap-anydpi-v26`): الشعار يملأ الأيقونة بدل أن يظهر صغيراً داخل إطار أبيض.
- الجسر `window.SawaNativeBridge` تستعمله الواجهة: `fcmToken` · `notifPermission` · `requestNotifPermission` · `googleSignIn` · `setInCall` · `callDone` · `openExternal` · `platform`.

يُبنى على GitHub Actions (`.github/workflows/build.yml`) من `sawa-native.zip`، بمفتاح TWA نفسه وبالمعرّف `com.sawaaap.app`، فيُثبَّت تحديثاً فوق التطبيق الحاليّ.
