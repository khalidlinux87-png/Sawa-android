# سوا — تطبيق أندرويد الأصليّ (C72)

يعرض www.sawaaap.com داخل WebView، مع أجزاء أصليّة:

- **إشعارات FCM أصليّة** (`SawaMessagingService`) بأولويّة عالية — تصل والتطبيق مغلق.
- **شاشة مكالمة واردة كاملة** فوق قفل الهاتف (`IncomingCallActivity` + إشعار `CallStyle`) بنغمة رنين الهاتف تتكرّر حتى الردّ أو الرفض.
- **خدمة «مكالمة جارية»** (`CallService`، خدمة أماميّة) تُبقي المكالمة والغرفة حيّتين في الخلفيّة، مع إشعارٍ بزرَّي «العودة» و«إنهاء».
- **الدخول بـGoogle أصليّاً** (Credential Manager)، لأنّ Google تمنع الدخول من داخل WebView.
- الجسر `window.SawaNativeBridge` تستعمله الواجهة: `fcmToken` · `notifPermission` · `requestNotifPermission` · `googleSignIn` · `setInCall` · `callDone` · `openExternal` · `platform`.

يُبنى على GitHub Actions (`.github/workflows/build.yml`) من `sawa-native.zip`، بمفتاح TWA نفسه وبالمعرّف `com.sawaaap.app`، فيُثبَّت تحديثاً فوق التطبيق الحاليّ.
